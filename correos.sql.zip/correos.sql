-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-05-2023 a las 19:35:11
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `correos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `correos`
--

CREATE TABLE `correos` (
  `id` int(11) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `tipo` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `correos`
--

INSERT INTO `correos` (`id`, `correo`, `tipo`, `status`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'olga.parra@univer-gdl.edu.mx', 1, 1, 'OCHOA PARRA OLGA LIDIA', '2023-05-24 19:16:57', NULL),
(2, 'bessie.sanchez@univer-gdl.edu.mx', 1, 2, 'SANCHEZ SUAREZ BESSIE', '2023-05-24 19:16:57', NULL),
(3, 'claudia.valdez@univer-gdl.edu.mx', 1, 2, 'VALDEZ AGUILAR CLAUDIA ELIZABETH', '2023-05-24 19:16:57', NULL),
(4, 'maricarmen.lugo@univer-gdl.edu.mx', 1, 2, 'LUGO BELICA MARIA DEL CARMEN', '2023-05-24 19:16:58', NULL),
(5, 'maria.contreras@univer-gdl.edu.mx', 1, 1, 'CONTRERAS CASILLAS MARIA GUADALUPE', '2023-05-24 19:16:58', NULL),
(6, 'bertha.aguila@univer-gdl.edu.mx', 1, 1, 'AGUILA RAMIREZ BERTHA ALEJANDRA', '2023-05-24 19:16:58', NULL),
(7, 'arlen.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA MUÃOZ ARLEN IYARI', '2023-05-24 19:16:58', NULL),
(8, 'diseno@univer-gdl.edu.mx', 1, 1, 'DIAZ CARCOBA JOSE MARIA', '2023-05-24 19:16:58', NULL),
(9, 'andrea.vazquez@univer-gdl.edu.mx', 1, 1, 'VAZQUEZ COVARRUBIAS ANDREA VIRIDIANA', '2023-05-24 19:16:58', NULL),
(10, 'carlos.delahoya@univer-gdl.edu.mx', 1, 1, 'DE LA HOYA CABRAL CARLOS JAVIER', '2023-05-24 19:16:58', NULL),
(11, 'cinthia.robles@univer-gdl.edu.mx', 1, 1, 'ROBLES OYERVIDES CINTHIA ALEJANDRA', '2023-05-24 19:16:58', NULL),
(12, 'maria.flores@univer-gdl.edu.mx', 1, 1, 'FLORES DAMIAN MARIA EUGENIA', '2023-05-24 19:16:58', NULL),
(13, 'olivia.lopez@univer-gdl.edu.mx', 1, 1, 'LOPEZ VARGAS OLIVIA', '2023-05-24 19:16:58', NULL),
(14, 'lauri.palomino@univer-gdl.edu.mx', 1, 1, 'MIRANDA PALOMINO LAURI CRISOL', '2023-05-24 19:16:58', NULL),
(15, 'omar.consebida@univer-gdl.edu.mx', 1, 1, 'CONSEBIDA SAUCEDO OMAR', '2023-05-24 19:16:58', NULL),
(16, 'rosa.chavez@univer-gdl.edu.mx', 1, 1, 'CHAVEZ MEZA ROSA ISABEL', '2023-05-24 19:16:58', NULL),
(17, 'teresa.almaraz@univer-gdl.edu.mx', 1, 1, 'ALMARAZ FLORES TERESA', '2023-05-24 19:16:59', NULL),
(18, 'angel.covarrubias@univer-gdl.edu.mx', 1, 1, 'COVARRUBIAS LOZANO JOSE ANGEL', '2023-05-24 19:16:59', NULL),
(19, 'samantha.perez@univer-gdl.edu.mx', 1, 1, 'PEREZ DE LOS SANTOS SAMANTHA ABIGAIL', '2023-05-24 19:16:59', NULL),
(20, 'martha.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA SORIANO MARTHA MARIA DE JESUS', '2023-05-24 19:16:59', NULL),
(21, 'selene.parra@univer-gdl.edu.mx', 1, 1, 'PARRA PADILLA SELENE GUADALUPE', '2023-05-24 19:16:59', NULL),
(22, 'sonia.morales@univer-gdl.edu.mx', 1, 1, 'MORALES MORENO SONIA BERENICE', '2023-05-24 19:16:59', NULL),
(23, 'yezmin.altamirano@univer-gdl.edu.mx', 1, 1, 'ALTAMIRANO MORALES YEZMIN PATRICIA', '2023-05-24 19:16:59', NULL),
(24, 'diana.rodriguez@univer-gdl.edu.mx', 1, 1, 'RODRIGUEZ DIAZ DIANA PAOLA', '2023-05-24 19:16:59', NULL),
(25, 'maria.perez@univer-gdl.edu.mx', 1, 1, 'PEREZ ARELLANO MARIA TERESA', '2023-05-24 19:16:59', NULL),
(26, 'karla.rivera@univer-gdl.edu.mx', 1, 1, 'RIVERA BRAMONT KARLA YASMIN', '2023-05-24 19:16:59', NULL),
(27, 'fatima.perez@univer-gdl.edu.mx', 1, 1, 'PEREZ PEREZ FATIMA', '2023-05-24 19:16:59', NULL),
(28, 'monserrat.ochoa@univer-gdl.edu.mx', 1, 1, 'OCHOA GUTIERREZ MONSERRAT', '2023-05-24 19:16:59', NULL),
(29, 'dinorah.ibarra@univer-gdl.edu.mx', 1, 1, 'IBARRA ROSALES DINORAH GUADALUPE', '2023-05-24 19:16:59', NULL),
(30, 'juan.lopez@univer-gdl.edu.mx', 1, 1, 'LOPEZ MORALES JUAN CARLOS', '2023-05-24 19:16:59', NULL),
(31, 'leticia.castro@univer-gdl.edu.mx', 1, 1, 'CASTRO BUENDIA MARIA LETICIA', '2023-05-24 19:16:59', NULL),
(32, 'edgar.lopez@univer-gdl.edu.mx', 1, 1, 'GARCIA LOPEZ EDGAR', '2023-05-24 19:16:59', NULL),
(33, 'edgar.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA LOPEZ EDGAR', '2023-05-24 19:16:59', NULL),
(34, 'andrea.caballero@univer-gdl.edu.mx', 1, 1, 'CABALLERO SENCION ANDREA CATALINA', '2023-05-24 19:16:59', NULL),
(35, 'jose.castaneda@univer-gdl.edu.mx', 1, 1, 'CASTAÃEDA RUBI JOSE LUIS', '2023-05-24 19:16:59', NULL),
(36, 'rodrigo.lopez@univer-gdl.edu.mx', 1, 1, 'LOPEZ GUZMAN RODRIGO IGNACIO', '2023-05-24 19:16:59', NULL),
(37, 'gustavo.chavez@univer-gdl.edu.mx', 1, 1, 'CHAVEZ ZAPATA GUSTAVO', '2023-05-24 19:16:59', NULL),
(38, 'francisco.monroy@univer-gdl.edu.mx', 1, 1, 'MONROY FERNANDEZ FRANCISCO JAVIER', '2023-05-24 19:16:59', NULL),
(39, 'magdalena.quintero@univer-gdl.edu.mx', 1, 1, 'QUINTERO ESQUIVEL MAGDALENA', '2023-05-24 19:16:59', NULL),
(40, 'flor.sanchez@univer-gdl.edu.mx', 1, 1, 'SANCHEZ SANCHEZ FLOR NATIVIDAD', '2023-05-24 19:17:00', NULL),
(41, 'hector.orozco@univer-gdl.edu.mx', 1, 1, 'OROZCO ESPARZA HECTOR CESAR', '2023-05-24 19:17:00', NULL),
(42, 'isela.suarez@univer-gdl.edu.mx', 1, 1, 'SUAREZ PEÃA ROSA ISELA', '2023-05-24 19:17:00', NULL),
(43, 'raul.romero@univer-gdl.edu.mx', 1, 1, 'ROMERO VIGIL RAUL ANGEL', '2023-05-24 19:17:00', NULL),
(44, 'leonardo.madrid@univer-gdl.edu.mx', 1, 1, 'MADRID QUEZADA LEONARDO', '2023-05-24 19:17:00', NULL),
(45, 'veronica.flores@univer-gdl.edu.mx', 1, 1, 'FLORES GARCIA VERONICA', '2023-05-24 19:17:00', NULL),
(46, 'fernando.ahumada@univer-gdl.edu.mx', 1, 1, 'AHUMADA SANCHEZ FERNANDO', '2023-05-24 19:17:00', NULL),
(47, 'alan.martinez@univer-gdl.edu.mx', 1, 1, 'MARTINEZ RAMIREZ ALAN ADAIR', '2023-05-24 19:17:00', NULL),
(48, 'octavio.pedroza@univer-gdl.edu.mx', 1, 1, 'PEDROZA FLORES CARLOS OCTAVIO', '2023-05-24 19:17:00', NULL),
(49, 'karina.alonso@univer-gdl.edu.mx', 1, 1, 'ALONSO TOSCANO KARINA MONSERRAT', '2023-05-24 19:17:00', NULL),
(50, 'hector.espinoza@univer-gdl.edu.mx', 1, 1, 'ESPINOZA JIMENEZ HECTOR', '2023-05-24 19:17:00', NULL),
(51, 'diana.jimenez@univer-gdl.edu.mx', 1, 1, 'JIMENEZ HIGUERA DIANA ELIZABETH', '2023-05-24 19:17:00', NULL),
(52, 'miriam.ruiz@univer-gdl.edu.mx', 1, 1, 'RUIZ GARCIA MIRIAM LIZBETH', '2023-05-24 19:17:00', NULL),
(53, 'karla.gutierrez@univer-gdl.edu.mx', 1, 1, 'GUTIERREZ GARCIA KARLA JUDITH', '2023-05-24 19:17:00', NULL),
(54, 'martha.fuentes@univer-gdl.edu.mx', 1, 1, 'FUENTES DELGADO MARTHA CECILIA', '2023-05-24 19:17:00', NULL),
(55, 'mayra.tolentino@univer-gdl.edu.mx', 1, 1, 'TOLENTINO IBARRA MAYRA', '2023-05-24 19:17:00', NULL),
(56, 'liliana.sanchez@univer-gdl.edu.mx', 1, 1, 'SANCHEZ VARGAS LILIANA VALERIA', '2023-05-24 19:17:00', NULL),
(57, 'lizbeth.sanchez@univer-gdl.edu.mx', 1, 1, 'SANCHEZ ANTE LIZBETH', '2023-05-24 19:17:00', NULL),
(58, 'gabino.vallejo@univer-gdl.edu.mx', 1, 1, 'VALLEJO ALMEIDA GABINO', '2023-05-24 19:17:00', NULL),
(59, 'ernesto.ramirez@univer-gdl.edu.mx', 1, 1, 'RAMIREZ AGUILAR MANUEL ERNESTO', '2023-05-24 19:17:00', NULL),
(60, 'maritza.camacho@univer-gdl.edu.mx', 1, 1, 'CAMACHO VALDEZ MARITZA ISABEL', '2023-05-24 19:17:00', NULL),
(61, 'gladys.morales@univer-gdl.edu.mx', 1, 1, 'MORALES BARO GLADYS OSVELIA', '2023-05-24 19:17:00', NULL),
(62, 'karla.gonzalez@univer-gdl.edu.mx', 1, 1, 'GONZALEZ GUTIERREZ KARLA CRISTINA', '2023-05-24 19:17:01', NULL),
(63, 'cesar.aguilera@univer-gdl.edu.mx', 1, 1, 'AGUILERA ZARAGOZA CESAR GERARDO', '2023-05-24 19:17:01', NULL),
(64, 'dalia.munoz@univer-gdl.edu.mx', 1, 1, 'MUÃOZ CARLIN DALIA ELENA', '2023-05-24 19:17:01', NULL),
(65, 'hugo.salvador@univer-gdl.edu.mx', 1, 1, 'SALVADOR MENDOZA HUGO FRANCISCO JESUS', '2023-05-24 19:17:01', NULL),
(66, 'andrea.navarro@univer-gdl.edu.mx', 1, 1, 'NAVARRO PEÃA ANDREA BERENICE', '2023-05-24 19:17:01', NULL),
(67, 'ulises.diaz@univer-gdl.edu.mx', 1, 1, 'DIAZ HERNANDEZ ULISES ALFREDO', '2023-05-24 19:17:01', NULL),
(68, 'josue.pimentel@univer-gdl.edu.mx', 1, 1, 'PIMENTEL FLORES JOSUE', '2023-05-24 19:17:01', NULL),
(69, 'maria.nava@univer-gdl.edu.mx', 1, 1, 'NAVA ROSARIO MARIA ELENA', '2023-05-24 19:17:01', NULL),
(70, 'arturo.tellez@univer-gdl.edu.mx', 1, 1, 'TELLEZ SEGURA ARTURO ANTONIO', '2023-05-24 19:17:01', NULL),
(71, 'eliseo.celis@univer-gdl.edu.mx', 1, 1, 'SANDOVAL CELIS ELISEO', '2023-05-24 19:17:01', NULL),
(72, 'guadalupe.zenteno@univer-gdl.edu.mx', 1, 1, 'ZENTENO MONDRAGON GUADALUPE', '2023-05-24 19:17:01', NULL),
(73, 'veronica.melo@univer-gdl.edu.mx', 1, 1, 'MELO ARTEAGA VERONICA IVON', '2023-05-24 19:17:01', NULL),
(74, 'diego.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA VILLANUEVA DIEGO', '2023-05-24 19:17:01', NULL),
(75, 'laura.barajas@univer-gdl.edu.mx', 1, 1, 'BARAJAS BUENROSTRO LAURA', '2023-05-24 19:17:01', NULL),
(76, 'eva.caixba@univer-gdl.edu.mx', 1, 1, 'CAIXBA TEOBAL EVA CECILIA', '2023-05-24 19:17:01', NULL),
(77, 'osvaldo.gutierrez@univer-gdl.edu.mx', 1, 1, 'GUTIERREZ PALAFOX OSVALDO DANIEL', '2023-05-24 19:17:01', NULL),
(78, 'diego.gomez@univer-gdl.edu.mx', 1, 1, 'GOMEZ AVILA DIEGO', '2023-05-24 19:17:01', NULL),
(79, 'fanny.padilla@univer-gdl.edu.mx', 1, 1, 'PADILLA RUBIO FANNY CAROLINA', '2023-05-24 19:17:01', NULL),
(80, 'juan.morales@univer-gdl.edu.mx', 1, 1, 'MORALES MORA JUAN CARLOS', '2023-05-24 19:17:01', NULL),
(81, 'ingrid.villanueva@univer-gdl.edu.mx', 1, 1, 'VILLANUEVA TAPIA INGRID VANESSA', '2023-05-24 19:17:01', NULL),
(82, 'viridiana.marquez@univer-gdl.edu.mx', 1, 1, 'MARQUEZ TERRIQUEZ VIRIDIANA', '2023-05-24 19:17:01', NULL),
(83, 'jorge.jimenez@univer-gdl.edu.mx', 1, 1, 'JIMENEZ PARTIDA JORGE ALEJANDRO', '2023-05-24 19:17:01', NULL),
(84, 'hector.guevara@univer-gdl.edu.mx', 1, 1, 'GUEVARA ANGEL HECTOR MANUEL', '2023-05-24 19:17:01', NULL),
(85, 'jonathan.gonzalez@univer-gdl.edu.mx', 1, 1, 'GONZALEZ GONZALEZ JONATHAN', '2023-05-24 19:17:02', NULL),
(86, 'cesar.plascencia@univer-gdl.edu.mx', 1, 1, 'PLASCENCIA RIVAS CESAR EDUARDO', '2023-05-24 19:17:02', NULL),
(87, 'francisco.flores@univer-gdl.edu.mx', 1, 1, 'FLORES ZAMBRANO FRANCISCO JAVIER', '2023-05-24 19:17:02', NULL),
(88, 'joel.palma@univer-gdl.edu.mx', 1, 1, 'PALMA GARCIA JOEL MILTON', '2023-05-24 19:17:02', NULL),
(89, 'olga.camacho@univer-gdl.edu.mx', 1, 1, 'CAMACHO AVALOS OLGA MONSERRAT', '2023-05-24 19:17:02', NULL),
(90, 'tatiana.velazco@univer-gdl.edu.mx', 1, 1, 'VELAZCO VELAZQUEZ TATIANA ESTEFANIA', '2023-05-24 19:17:02', NULL),
(91, 'paola.deanda@univer-gdl.edu.mx', 1, 1, 'DE ANDA LUNA PAOLA TERESA', '2023-05-24 19:17:02', NULL),
(92, 'berenice.bejarano@univer-gdl.edu.mx', 1, 1, 'BEJARANO PEREZ KARLA BERENICE', '2023-05-24 19:17:02', NULL),
(93, 'raymundo.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA SOTELO RAYMUNDO JORGE', '2023-05-24 19:17:02', NULL),
(94, 'maria.amezquita@univer-gdl.edu.mx', 1, 1, 'AMEZQUITA RODRIGUEZ MARIA DEL ROCIO', '2023-05-24 19:17:02', NULL),
(95, 'ruben.salazar@univer-gdl.edu.mx', 1, 1, 'SALAZAR PEREZ RUBEN', '2023-05-24 19:17:02', NULL),
(96, 'alma.castro@univer-gdl.edu.mx', 1, 1, 'CASTRO CASTILLO ALMA DELIA', '2023-05-24 19:17:02', NULL),
(97, 'claudia.hernandez@univer-gdl.edu.mx', 1, 1, 'HERNANDEZ RAMIREZ CLAUDIA IVONNE', '2023-05-24 19:17:02', NULL),
(98, 'andres.lopez@univer-gdl.edu.mx', 1, 1, 'LOPEZ CARDENAS ANDRES', '2023-05-24 19:17:02', NULL),
(99, 'oswaldo.soria@univer-gdl.edu.mx', 1, 1, 'SORIA LARA JORGE OSWALDO', '2023-05-24 19:17:02', NULL),
(100, 'julio.contreras@univer-gdl.edu.mx', 1, 1, 'CONTRERAS DE LEON JULIO CESAR', '2023-05-24 19:17:02', NULL),
(101, 'daniel.ramirez@univer-gdl.edu.mx', 1, 1, 'RAMIREZ LARA DANIEL', '2023-05-24 19:17:02', NULL),
(102, 'ricardo.arechiga@univer-gdl.edu.mx', 1, 1, 'ARECHIGA TALANCON RICARDO', '2023-05-24 19:17:02', NULL),
(103, 'cesar.chavarin@univer-gdl.edu.mx', 1, 1, 'CHAVARIN DAVALOS CESAR FRANCISCO', '2023-05-24 19:17:02', NULL),
(104, 'alejandrina.lopez@univer-gdl.edu.mx', 1, 1, 'LOPEZ AGUILAR ALEJANDRINA', '2023-05-24 19:17:02', NULL),
(105, 'alejandro.raga@univer-gdl.edu.mx', 1, 1, 'RAGA PEREZ ALEJANDRO', '2023-05-24 19:17:03', NULL),
(106, 'diana.deleon@univer-gdl.edu.mx', 1, 1, 'DE LEON CUEVAS. DIANA MARISOL', '2023-05-24 19:17:03', NULL),
(107, 'eduardo.millan@univer-gdl.edu.mx', 1, 1, 'QUIÃONEZ MILLAN EDUARDO', '2023-05-24 19:17:03', NULL),
(108, 'esther.salas@univer-gdl.edu.mx', 1, 1, 'SALAS DE LA CRUZ ESTHER', '2023-05-24 19:17:03', NULL),
(109, 'janet.gil@univer-gdl.edu.mx', 1, 1, 'GIL SAMANIEGO JANET', '2023-05-24 19:17:03', NULL),
(110, 'jazmin.amador@univer-gdl.edu.mx', 1, 1, 'AMADOR FIGUEROA JAZMIN', '2023-05-24 19:17:03', NULL),
(111, 'johana.rendon@univer-gdl.edu.mx', 1, 1, 'RENDON OCHOA JOHANA LIZETH', '2023-05-24 19:17:03', NULL),
(112, 'jessica.mongrif@univer-gdl.edu.mx', 1, 1, 'Jessica Mongrif IÃ±iguez', '2023-05-24 19:17:03', NULL),
(113, 'jorge.alonso@univer-gdl.edu.mx', 1, 1, 'ALONSO NAVA JORGE HUMBERTO', '2023-05-24 19:17:03', NULL),
(114, 'leonor.montesdeoca@univer-gdl.edu.mx', 1, 1, 'MONTES DE OCA GONZALEZ LEONOR MARIA TERESA DEL CARMEN', '2023-05-24 19:17:03', NULL),
(115, 'luis.soberanis@univer-gdl.edu.mx', 1, 1, 'SOBERANIS LUIS', '2023-05-24 19:17:03', NULL),
(116, 'luis.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA RAIGOSA LUIS', '2023-05-24 19:17:03', NULL),
(117, 'maria.garcia@univer-gdl.edu.mx', 1, 1, 'GARCIA MADRIGAL MARI SOL', '2023-05-24 19:17:03', NULL),
(118, 'areli.delgado@univer-gdl.edu.mx', 1, 1, 'DELGADO ESPINOSA ARELI', '2023-05-24 19:17:03', NULL),
(119, 'edgar.iniguez@univer-gdl.edu.mx', 1, 1, 'IÃIGUEZ EDGAR G.', '2023-05-24 19:17:03', NULL),
(120, 'esteban.godinez@univer-gdl.edu.mx', 1, 1, 'GODINEZ MEJIA ESTEBAN', '2023-05-24 19:17:03', NULL),
(121, 'experiencia.estudiantil@univer-gdl.edu.mx', 1, 1, 'UNIVER EXPERIENCIA. ESTUDIANTIL', '2023-05-24 19:17:03', NULL),
(122, 'monica.yanez@univer-gdl.edu.mx', 1, 1, 'YAÃEZ RAMIREZ MONICA', '2023-05-24 19:17:03', NULL),
(123, 'vianeth.barragan@univer-gdl.edu.mx', 1, 1, 'BARRAGAN JIMENEZ VIANETH', '2023-05-24 19:17:03', NULL),
(124, 'ricardo.sanchez@univer-gdl.edu.mx', 1, 1, 'Ricardo Sanchez Ortiz', '2023-05-24 19:17:03', NULL),
(125, 'eric.guerrero@univer-gdl.edu.mx', 1, 1, 'Eric Netzahualcoyotl Guerrero Araujo', '2023-05-24 19:17:04', NULL),
(126, 'sarai.zepeda@univer-gdl.edu.mx', 1, 1, 'Sandra Sarai Zepeda Morales', '2023-05-24 19:17:04', NULL),
(127, 'angelica.barragan@univer-gdl.edu.mx', 1, 1, 'Angelica Danae Barragan Marquez', '2023-05-24 19:17:04', NULL),
(128, 'jonatan.siordia@univer-gdl.edu.mx', 1, 1, 'Jonatan Adalberto Siordia Chavez', '2023-05-24 19:17:04', NULL),
(129, 'jose.garcia@univer-gdl.edu.mx', 1, 1, 'Jose Luis Garcia Mariscal', '2023-05-24 19:17:04', NULL),
(130, 'daniel.hernandez@univer-gdl.edu.mx', 1, 1, 'Daniel Octavio Hernandez PeÃ±a', '2023-05-24 19:17:04', NULL),
(131, 'luis.gomez@univer-gdl.edu.mx', 1, 1, 'Luis Alberto Gomez Ruiz', '2023-05-24 19:17:04', NULL),
(132, 'gregorio.avila@univer-gdl.edu.mx', 1, 1, 'Gregorio Moises Avila Dorado', '2023-05-24 19:17:04', NULL),
(133, 'isaac.aguilar@univer-gdl.edu.mx', 1, 1, 'Isaac Armando Aguilar Parra', '2023-05-24 19:17:04', NULL),
(134, 'stephany.espinoza@univer-gdl.edu.mx', 1, 1, 'Stephany Espinoza Jimenez', '2023-05-24 19:17:04', NULL),
(135, 'gabriela.gallo@univer-gdl.edu.mx', 1, 1, 'Gabriela Yudtih Gallo Placencia', '2023-05-24 19:17:04', NULL),
(136, 'marco.chavez@univer-gdl.edu.mx', 1, 1, 'Marco Antonio Chavez Rosas', '2023-05-24 19:17:04', NULL),
(137, 'omar.orozco@univer-gdl.edu.mx', 1, 1, 'Omar Orozco Coria', '2023-05-24 19:17:04', NULL),
(138, 'claudia.chavez@univer-gdl.edu.mx', 1, 1, 'Claudia ChÃ¡vez Velarde', '2023-05-24 19:17:04', NULL),
(139, 'brayton.jimenez@univer-gdl.edu.mx', 1, 1, 'Brayton Fernando Jimenez Perez', '2023-05-24 19:17:04', NULL),
(140, 'javier.puente@univer-gdl.edu.mx', 1, 1, 'Puente Cerda Javier Emmanuel', '2023-05-24 19:17:04', NULL),
(141, 'jaime.arteaga@univer-gdl.edu.mx', 1, 1, 'Jaime Abraham Arteaga Padilla', '2023-05-24 19:17:04', NULL),
(142, 'jesus.flores@univer-gdl.edu.mx', 1, 1, 'Flores Cabrera JesÃºs', '2023-05-24 19:17:04', NULL),
(143, 'jesus.campos@univer-gdl.edu.mx', 1, 1, 'JesÃºs Alan Campos Quezada', '2023-05-24 19:17:05', NULL),
(144, 'daniela.cisneros@univer-gdl.edu.mx', 1, 1, 'Daniela Cisneros Jarquin', '2023-05-24 19:17:05', NULL),
(145, 'maricarmen.martinez@univer-gdl.edu.mx', 1, 1, 'Maricarmen Martinez Baron', '2023-05-24 19:17:05', NULL),
(146, 'fabiola.hernandez@univer-gdl.edu.mx', 1, 1, 'Fabiola Hernandez Hernandez', '2023-05-24 19:17:05', NULL),
(147, 'andrea.rodriguez@univer-gdl.edu.mx', 1, 1, 'Andrea Guadalupe RodrÃ­guez Gonzalez', '2023-05-24 19:17:05', NULL),
(148, 'victor.marquez@univer-gdl.edu.mx', 1, 1, 'Victor Emmanuel MÃ¡rquez Mendoza', '2023-05-24 19:17:05', NULL),
(149, 'yolanda.vivanco@univer-gdl.edu.mx', 1, 1, 'Yolanda del Rocio Vivanco CaÃ±izares', '2023-05-24 19:17:05', NULL),
(150, 'raymundo.regalado@univer-gdl.edu.mx', 1, 1, 'RamÃ³n Raymundo Regalado Herrera', '2023-05-24 19:17:05', NULL),
(151, 'ivan.becerra@univer-gdl.edu.mx', 1, 1, 'Ivan Isai Becerra Gutierrez', '2023-05-24 19:17:05', NULL),
(152, 'nestor.rosales@univer-gdl.edu.mx', 1, 1, 'Nestor Noe Rosales Contrares', '2023-05-24 19:17:05', NULL),
(153, 'itzel.arevalo@univer-gdl.edu.mx', 1, 1, 'Itzel Nathalie Arevalo Torres', '2023-05-24 19:17:05', NULL),
(154, 'liliana.rodriguez@univer-gdl.edu.mx', 1, 1, 'Liliana Beatriz Rodriguez Santacruz', '2023-05-24 19:17:05', NULL),
(155, 'itzel.villanueva@univer-gdl.edu.mx', 1, 1, 'Itzel Alejandra Villanueva Duran', '2023-05-24 19:17:05', NULL),
(156, 'mario.jasso@univer-gdl.edu.mx', 1, 1, 'Mario Alberto Jasso Salcido', '2023-05-24 19:17:05', NULL),
(157, 'maria.castellanos@univer-gdl.edu.mx', 1, 1, 'Maria Del Carmen Castellanos Abundis', '2023-05-24 19:17:05', NULL),
(158, 'hugo.ramirez@univer-gdl.edu.mx', 1, 1, 'Hugo Enrique Ramirez Rodriguez', '2023-05-24 19:17:06', NULL),
(159, 'cecilia.ruiz@univer-gdl.edu.mx', 1, 1, 'Miriam Cecilia Ruiz Alonso', '2023-05-24 19:17:06', NULL),
(160, 'angelica.castellanos@univer-gdl.edu.mx', 1, 1, 'Angelica Del Carmen Castellanos Abundis', '2023-05-24 19:17:06', NULL),
(161, 'lorena.mendoza@univer-gdl.edu.mx', 1, 1, 'Lorena Mendoza Cabrera', '2023-05-24 19:17:06', NULL),
(162, 'mirna.sandoval@univer-gdl.edu.mx', 1, 1, 'Mirna Paulina Sandoval Sandoval', '2023-05-24 19:17:06', NULL),
(163, 'sandra.valdivia@univer-gdl.edu.mx', 1, 1, 'Sandra Patricia Valdivia Hernandez', '2023-05-24 19:17:06', NULL),
(164, 'alfaro.campos@univer-gdl.edu.mx', 1, 1, 'Alfaro Campos Cuauhtemoc', '2023-05-24 19:17:06', NULL),
(165, 'victoria.gutierrez@univer-gdl.edu.mx', 1, 1, 'Victoria Sarahi Gutierrez Guzman', '2023-05-24 19:17:06', NULL),
(166, 'leydi.esparza@univer-gdl.edu.mx', 1, 1, 'Leydi Laura Esparza Garcia', '2023-05-24 19:17:06', NULL),
(167, 'francisco.contreras@univer-gdl.edu.mx', 1, 1, 'Francisco Javier Contreras Alcala', '2023-05-24 19:17:06', NULL),
(168, 'diana.perez@univer-gdl.edu.mx', 1, 1, 'Diana Areli Perez Hernandez', '2023-05-24 19:17:06', NULL),
(169, 'daniel.ulloa@univer-gdl.edu.mx', 1, 1, 'Daniel Ulloa Lozano', '2023-05-24 19:17:06', NULL),
(170, 'isis.padilla@univer-gdl.edu.mx', 1, 1, 'Isis Shalom Cassandra Padilla GutiÃ©rrez', '2023-05-24 19:17:06', NULL),
(171, 'jesus.ramirez@univer-gdl.edu.mx', 1, 1, 'JesÃºs RaÃºl RamÃ­rez Castillo', '2023-05-24 19:17:06', NULL),
(172, 'cesar.limon@univer-gdl.edu.mx', 1, 1, 'Cesar German Limon Lopez', '2023-05-24 19:17:06', NULL),
(173, 'rafael.jimenez@univer-gdl.edu.mx', 1, 1, 'Benito Rafael IÃ±iguez Jimenez', '2023-05-24 19:17:06', NULL),
(174, 'victor.beltran@univer-gdl.edu.mx', 1, 1, 'Victor Manuel Beltran Aguilera', '2023-05-24 19:17:06', NULL),
(175, 'silvia.avilez@univer-gdl.edu.mx', 1, 1, 'Silvia Yolanda Avilez Rodriguez', '2023-05-24 19:17:06', NULL),
(176, 'veronica.gutierrez@univer-gdl.edu.mx', 1, 1, 'Veronica Gutierrez Elizondo', '2023-05-24 19:17:07', NULL),
(177, 'marcela.velasco@univer-gdl.edu.mx', 1, 1, 'MarÃ­a Marcela Velasco', '2023-05-24 19:17:07', NULL),
(178, 'ximena.mendez@univer-gdl.edu.mx', 1, 1, 'Ximena MÃ©ndez De LeÃ³n', '2023-05-24 19:17:07', NULL),
(179, 'elvia.manzanarez@univer-gdl.edu.mx', 1, 1, 'Elvia Manzanarez Flores', '2023-05-24 19:17:07', NULL),
(180, 'javier.ascencio@univer-gdl.edu.mx', 1, 1, 'Javier Alejandro Ascencio NÃ¡jera', '2023-05-24 19:17:07', NULL),
(181, 'paola.carranza@univer-gdl.edu.mx', 1, 1, 'Paola Lizette Carranza PeÃ±a', '2023-05-24 19:17:07', NULL),
(182, 'angelica.garcia@univer-gdl.edu.mx', 1, 1, 'AngÃ©lica Jisselle GarcÃ­a Salazar', '2023-05-24 19:17:07', NULL),
(183, 'irma.ayala@univer-gdl.edu.mx', 1, 1, 'Irma Ivonne Ayala Lopez', '2023-05-24 19:17:07', NULL),
(184, 'ivan.miranda@univer-gdl.edu.mx', 1, 1, 'IvÃ¡n Miranda SÃ¡nchez', '2023-05-24 19:17:07', NULL),
(185, 'david.gonzalez@univer-gdl.edu.mx', 1, 1, 'David Gerardo Gonzalez Carrillo', '2023-05-24 19:17:07', NULL),
(186, 'danyael.zamora@univer-gdl.edu.mx', 1, 1, 'Danyael Zamora Cordova', '2023-05-24 19:17:07', NULL),
(187, 'veronica.hernandez@univer-gdl.edu.mx', 1, 1, 'Veronica Marcela HernÃ¡ndez Manrriquez', '2023-05-24 19:17:07', NULL),
(188, 'selene.medina@univer-gdl.edu.mx', 1, 1, 'Selene Alejandra Medina Martinez', '2023-05-24 19:17:07', NULL),
(189, 'nancy.elizabeth@univer-gdl.edu.mx', 1, 1, 'Nancy Elizabeth Aguilar', '2023-05-24 19:17:07', NULL),
(190, 'jorge.soto@univer-gdl.edu.mx', 1, 1, 'Jorge Alberto Soto TristÃ¡n', '2023-05-24 19:17:07', NULL),
(191, 'israel.nieves@univer-gdl.edu.mx', 1, 1, 'Israel Nieves Vazquez', '2023-05-24 19:17:07', NULL),
(192, 'claudia.espinosa@univer-gdl.edu.mx', 1, 1, 'Claudia Cristina Espinosa Mora', '2023-05-24 19:17:07', NULL),
(193, 'antonio.acevedo@docente.univer-gdl.edu.mx', 2, 1, 'ACEVEDO GUEVARA ANTONIO VLADIMYR', '2023-05-24 19:17:32', NULL),
(194, 'roman.aceves@docente.univer-gdl.edu.mx', 2, 1, 'ACEVES AVALOS ROMAN', '2023-05-24 19:17:32', NULL),
(195, 'gustavo.acosta@docente.univer-gdl.edu.mx', 2, 1, 'ACOSTA ROJAS GUSTAVO ROBERTO', '2023-05-24 19:17:32', NULL),
(196, 'maria.aguilar@docente.univer-gdl.edu.mx', 2, 1, 'AGUILAR HERNANDEZ MARIA DE LOURDES', '2023-05-24 19:17:32', NULL),
(197, 'selene.aguilar@docente.univer-gdl.edu.mx', 2, 1, 'AGUILAR ROJAS SELENE', '2023-05-24 19:17:32', NULL),
(198, 'german.sosa@docente.univer-gdl.edu.mx', 2, 1, 'AGUILAR SOSA GERMAN', '2023-05-24 19:17:32', NULL),
(199, 'maria.aguilera@docente.univer-gdl.edu.mx', 2, 1, 'AGUILERA SERRANO MARIA GUADALUPE', '2023-05-24 19:17:32', NULL),
(200, 'manuel.aguinaga@docente.univer-gdl.edu.mx', 2, 1, 'AGUIÃAGA LAMAS MANUEL', '2023-05-24 19:17:32', NULL),
(201, 'carlos.albanes@docente.univer-gdl.edu.mx', 2, 1, 'ALBANES GARCIA GUILLERMO CARLOS', '2023-05-24 19:17:32', NULL),
(202, 'sofia.garcia@docente.univer-gdl.edu.mx', 2, 1, 'ALCALA GARCIA SOFIA', '2023-05-24 19:17:32', NULL),
(203, 'gerardo.aldaba@docente.univer-gdl.edu.mx', 2, 1, 'ALDABA ORNELAS GERARDO DAVID', '2023-05-24 19:17:32', NULL),
(204, 'jose.altamirano@docente.univer-gdl.edu.mx', 2, 1, 'ALTAMIRANO MORALES OCTAVIANO', '2023-05-24 19:17:32', NULL),
(205, 'miguel.altamirano@docente.univer-gdl.edu.mx', 2, 1, 'ALTAMIRANO OROZCO JESUS MIGUEL ANGEL', '2023-05-24 19:17:32', NULL),
(206, 'gustavo.altamirano@docente.univer-gdl.edu.mx', 2, 1, 'ALTAMIRANO RAMIREZ GUSTAVO ADOLFO', '2023-05-24 19:17:33', NULL),
(207, 'alberto.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'ALVAREZ HERNANDEZ CARLOS ALBERTO', '2023-05-24 19:17:33', NULL),
(208, 'sabas.alvarez@docente.univer-gdl.edu.mx', 2, 1, 'ALVAREZ LOZOYA SABAS ARTURO HUIZILOPOCHTLI', '2023-05-24 19:17:33', NULL),
(209, 'heriberto.alvarez@docente.univer-gdl.edu.mx', 2, 1, 'ALVAREZ NUÃEZ HERIBERTO', '2023-05-24 19:17:33', NULL),
(210, 'paola.alvarez@docente.univer-gdl.edu.mx', 2, 1, 'ALVAREZ ZUÃIGA PAOLA', '2023-05-24 19:17:33', NULL),
(211, 'ignacio.amezquita@docente.univer-gdl.edu.mx', 2, 1, 'AMEZQUITA GONZALEZ IGNACIO', '2023-05-24 19:17:33', NULL),
(212, 'karen.araiza@docente.univer-gdl.edu.mx', 2, 1, 'ARAIZA ALCARAZ KAREN BEATRIZ', '2023-05-24 19:17:33', NULL),
(213, 'alan.arce@docente.univer-gdl.edu.mx', 2, 1, 'ARCE ALCANTARA ALAN YASMANI', '2023-05-24 19:17:33', NULL),
(214, 'sofia.arechiga@docente.univer-gdl.edu.mx', 2, 1, 'ARECHIGA MARTINEZ SOFIA', '2023-05-24 19:17:33', NULL),
(215, 'yazmin.vargas@docente.univer-gdl.edu.mx', 2, 1, 'AREVALO VARGAS YAZMIN', '2023-05-24 19:17:33', NULL),
(216, 'luis.arias@docente.univer-gdl.edu.mx', 2, 1, 'ARIAS GONZALEZ LUIS IGNACIO', '2023-05-24 19:17:33', NULL),
(217, 'erick.armenta@docente.univer-gdl.edu.mx', 2, 1, 'ARMENTA MARQUEZ ERICK ARMANDO', '2023-05-24 19:17:33', NULL),
(218, 'mario.arrieta@docente.univer-gdl.edu.mx', 2, 1, 'ARRIETA GONZALEZ MARIO ALBERTO', '2023-05-24 19:17:33', NULL),
(219, 'rosalina.ascencio@docente.univer-gdl.edu.mx', 2, 1, 'ASCENCIO LOMELI ROSALINA', '2023-05-24 19:17:33', NULL),
(220, 'veronica.atanacio@docente.univer-gdl.edu.mx', 2, 1, 'Atanacio Diego Veronica Griselda', '2023-05-24 19:17:34', NULL),
(221, 'rossana.avila@docente.univer-gdl.edu.mx', 2, 1, 'AVILA MORA ROSSANA ISABEL', '2023-05-24 19:17:34', NULL),
(222, 'carmen.moran@docente.univer-gdl.edu.mx', 2, 1, 'BALDERAS MORAN CARMEN PAULETH', '2023-05-24 19:17:34', NULL),
(223, 'maria.balver@docente.univer-gdl.edu.mx', 2, 1, 'BALVER ALVAREZ MARIA DE LOS ANGELES', '2023-05-24 19:17:34', NULL),
(224, 'paulina.bancalari@docente.univer-gdl.edu.mx', 2, 1, 'BANCALARI SANCHEZ PAULINA', '2023-05-24 19:17:34', NULL),
(225, 'carlos.barrera@docente.univer-gdl.edu.mx', 2, 1, 'BARRERA MENDEZ CARLOS ANDRES', '2023-05-24 19:17:34', NULL),
(226, 'francisco.barrios@docente.univer-gdl.edu.mx', 2, 1, 'BARRIOS JIMENEZ FRANCISCO MANUEL', '2023-05-24 19:17:34', NULL),
(227, 'david.velazquez@docente.univer-gdl.edu.mx', 2, 1, 'BENITEZ VELAZQUEZ DAVID', '2023-05-24 19:17:34', NULL),
(228, 'lizbeth.lopez@docente.univer-gdl.edu.mx', 2, 1, 'BERNAL LOPEZ CLARA LIZBETH', '2023-05-24 19:17:34', NULL),
(229, 'alberto.bojorquez@docente.univer-gdl.edu.mx', 2, 1, 'BOJORQUEZ BECERRIL ALBERTO', '2023-05-24 19:17:34', NULL),
(230, 'veronica.bolanos@docente.univer-gdl.edu.mx', 2, 1, 'BOLAÃOS MALDONADO VERONICA', '2023-05-24 19:17:34', NULL),
(231, 'maria.bonavia@docente.univer-gdl.edu.mx', 2, 1, 'BONAVIA CASTRO MARIA DE LOS ANGELES', '2023-05-24 19:17:34', NULL),
(232, 'jesus.bravo@docente.univer-gdl.edu.mx', 2, 1, 'BRAVO BERMUDES JESUS', '2023-05-24 19:17:34', NULL),
(233, 'alejandro.amezcua@docente.univer-gdl.edu.mx', 2, 1, 'BRISEÃO AMEZCUA ALEJANDRO', '2023-05-24 19:17:34', NULL),
(234, 'cynthia.brizuela@docente.univer-gdl.edu.mx', 2, 1, 'BRIZUELA PEREZ CYNTHIA', '2023-05-24 19:17:34', NULL),
(235, 'himelda.buenrostro@docente.univer-gdl.edu.mx', 2, 1, 'BUENROSTRO RUBIO HIMELDA', '2023-05-24 19:17:34', NULL),
(236, 'francisco.loyola@docente.univer-gdl.edu.mx', 2, 1, 'CABRALES LOYOLA FRANCISCO', '2023-05-24 19:17:34', NULL),
(237, 'janssen.cabrera@docente.univer-gdl.edu.mx', 2, 1, 'CABRERA ABUD JANSSEN JANETTE', '2023-05-24 19:17:34', NULL),
(238, 'maria.cabrera@docente.univer-gdl.edu.mx', 2, 1, 'CABRERA GONZALEZ MARIA TERESA', '2023-05-24 19:17:35', NULL),
(239, 'rafael.cadena@docente.univer-gdl.edu.mx', 2, 1, 'CADENA ALARCON RAFAEL', '2023-05-24 19:17:35', NULL),
(240, 'javier.calderon@docente.univer-gdl.edu.mx', 2, 1, 'CALDERON GARCIA JAVIER EDUARDO', '2023-05-24 19:17:35', NULL),
(241, 'anitrebla.camacho@docente.univer-gdl.edu.mx', 2, 1, 'CAMACHO NIEBLA ANITREBLA', '2023-05-24 19:17:35', NULL),
(242, 'mauricio.camarena@docente.univer-gdl.edu.mx', 2, 1, 'CAMARENA GONZALEZ MAURICIO', '2023-05-24 19:17:35', NULL),
(243, 'alfonso.camarillo@docente.univer-gdl.edu.mx', 2, 1, 'CAMARILLO OCEGUEDA ALFONSO', '2023-05-24 19:17:35', NULL),
(244, 'mario.campos@docente.univer-gdl.edu.mx', 2, 1, 'CAMPOS CAMACHO MARIO ALBERTO', '2023-05-24 19:17:35', NULL),
(245, 'jose.cardenas@docente.univer-gdl.edu.mx', 2, 1, 'CARDENAS NIEVES JOSE DE JESUS', '2023-05-24 19:17:35', NULL),
(246, 'edgar.cardenas@docente.univer-gdl.edu.mx', 2, 1, 'CARDENAS SANCHEZ EDGAR JAVIER', '2023-05-24 19:17:35', NULL),
(247, 'josmar.cardenas@docente.univer-gdl.edu.mx', 2, 1, 'CARDENAS SIMENTAL JOSMAR ALEJANDRO', '2023-05-24 19:17:35', NULL),
(248, 'benjamin.cardenas@docente.univer-gdl.edu.mx', 2, 1, 'CARDENAS VERDUZCO JOSE BENJAMIN', '2023-05-24 19:17:35', NULL),
(249, 'carlos.cardona@docente.univer-gdl.edu.mx', 2, 1, 'CARDONA MENDEZ CARLOS EDUARDO', '2023-05-24 19:17:35', NULL),
(250, 'mayra.cocula@docente.univer-gdl.edu.mx', 2, 1, 'CASILLAS COCULA MAYRA IVETTE', '2023-05-24 19:17:35', NULL),
(251, 'hector.castellanos@docente.univer-gdl.edu.mx', 2, 1, 'CASTELLANOS BUENROSTRO HECTOR', '2023-05-24 19:17:35', NULL),
(252, 'sergio.castillon@docente.univer-gdl.edu.mx', 2, 1, 'CASTILLON ROBLES SERGIO ROBERTO', '2023-05-24 19:17:35', NULL),
(253, 'joel.castro@docente.univer-gdl.edu.mx', 2, 1, 'CASTRO AGUILERA JOEL IVAN', '2023-05-24 19:17:35', NULL),
(254, 'hector.castro@docente.univer-gdl.edu.mx', 2, 1, 'CASTRO GONZALEZ HECTOR FIDEL', '2023-05-24 19:17:36', NULL),
(255, 'maria.melchor@docente.univer-gdl.edu.mx', 2, 1, 'CASTRO MELCHOR MARIA DEL CARMEN', '2023-05-24 19:17:36', NULL),
(256, 'maria.cerda@docente.univer-gdl.edu.mx', 2, 1, 'CERDA JACOBO MARIA GRACIA', '2023-05-24 19:17:36', NULL),
(257, 'paula.ceron@docente.univer-gdl.edu.mx', 2, 1, 'CERON ALFARO PAULA ELIZABETH', '2023-05-24 19:17:36', NULL),
(258, 'francisco.cervantes@docente.univer-gdl.edu.mx', 2, 1, 'CERVANTES CORTES FRANCISCO JAVIER', '2023-05-24 19:17:36', NULL),
(259, 'daniel.galindo@docente.univer-gdl.edu.mx', 2, 1, 'CHAVARIN GALINDO DANI DANIEL', '2023-05-24 19:17:36', NULL),
(260, 'nestor.chavez@docente.univer-gdl.edu.mx', 2, 1, 'CHAVEZ LOPEZ JOSE NESTOR', '2023-05-24 19:17:36', NULL),
(261, 'jorge.chavoya@docente.univer-gdl.edu.mx', 2, 1, 'CHAVOYA GAMA JORGE MIGUEL', '2023-05-24 19:17:36', NULL),
(262, 'sergio.chimal@docente.univer-gdl.edu.mx', 2, 1, 'CHIMAL MENDEZ SERGIO ABRAHAM', '2023-05-24 19:17:36', NULL),
(263, 'javier.colmenares@docente.univer-gdl.edu.mx', 2, 1, 'COLMENARES DE LA TORRE JAVIER', '2023-05-24 19:17:36', NULL),
(264, 'lis.conde@docente.univer-gdl.edu.mx', 2, 1, 'CONDE ESCUDERO LIS CLAUDETTE', '2023-05-24 19:17:36', NULL),
(265, 'jesus.aguilar@docente.univer-gdl.edu.mx', 2, 1, 'CONTRERAS AGUILAR JESUS', '2023-05-24 19:17:36', NULL),
(266, 'jorge.coronado@docente.univer-gdl.edu.mx', 2, 1, 'CORONADO BARRAGAN JORGE GUILLERMO', '2023-05-24 19:17:36', NULL),
(267, 'jorge.cortes@docente.univer-gdl.edu.mx', 2, 1, 'CORTES RIOS JORGE ENRIQUE', '2023-05-24 19:17:36', NULL),
(268, 'martina.covarrubias@docente.univer-gdl.edu.mx', 2, 1, 'COVARRUBIAS BUGARIN MA. MARTINA OBDULIA', '2023-05-24 19:17:36', NULL),
(269, 'francisco.covarrubias@docente.univer-gdl.edu.mx', 2, 1, 'COVARRUBIAS ESTRADA FRANCISCO JAVIER', '2023-05-24 19:17:36', NULL),
(270, 'gricelda.covarrubias@docente.univer-gdl.edu.mx', 2, 1, 'COVARRUBIAS LEON GRICELDA ANGELICA', '2023-05-24 19:17:36', NULL),
(271, 'maricruz.cruz@docente.univer-gdl.edu.mx', 2, 1, 'CRUZ RAMIREZ MARICRUZ', '2023-05-24 19:17:37', NULL),
(272, 'cristina.cruz@docente.univer-gdl.edu.mx', 2, 1, 'CRUZ SANTIAGO CRISTINA GABRIELA', '2023-05-24 19:17:37', NULL),
(273, 'christhian.cuevas@docente.univer-gdl.edu.mx', 2, 1, 'CUEVAS HENGST CHRISTHIAN DE ASIS', '2023-05-24 19:17:37', NULL),
(274, 'gustavo.cuevas@docente.univer-gdl.edu.mx', 2, 1, 'CUEVAS TORRES GUSTAVO ALEJANDRO', '2023-05-24 19:17:37', NULL),
(275, 'jose.davila@docente.univer-gdl.edu.mx', 2, 1, 'DAVILA RIVAS JOSE JAIME', '2023-05-24 19:17:37', NULL),
(276, 'felipe.davila@docente.univer-gdl.edu.mx', 2, 1, 'DAVILA ZARAGOZA FELIPE DE JESUS', '2023-05-24 19:17:37', NULL),
(277, 'maria.sandoval@docente.univer-gdl.edu.mx', 2, 1, 'DE ALBA SANDOVAL MARIA DEL PILAR', '2023-05-24 19:17:37', NULL),
(278, 'carolina.frausto@docente.univer-gdl.edu.mx', 2, 1, 'DE ANDA FRAUSTO CAROLINA', '2023-05-24 19:17:37', NULL),
(279, 'laura.delapuente@docente.univer-gdl.edu.mx', 2, 1, 'DE LA PUENTE DIAZ LAURA VIOLETA', '2023-05-24 19:17:37', NULL),
(280, 'gloria.delarosa@docente.univer-gdl.edu.mx', 2, 1, 'DE LA ROSA MURILLO GLORIA ESTELA', '2023-05-24 19:17:37', NULL),
(281, 'arturo.frias@docente.univer-gdl.edu.mx', 2, 1, 'DE LA TORRE FRIAS ARTURO', '2023-05-24 19:17:37', NULL),
(282, 'nelson.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'DE LEON GONZALEZ NELSON', '2023-05-24 19:17:37', NULL),
(283, 'jorge.delangel@docente.univer-gdl.edu.mx', 2, 1, 'DEL ANGEL SANTIAGO JORGE ALBERTO', '2023-05-24 19:17:37', NULL),
(284, 'israel.delvalle@univer-gdl.edu.mx', 2, 1, 'DEL VALLE ZENTENO ISRAEL', '2023-05-24 19:17:37', NULL),
(285, 'luz.delgadillo@docente.univer-gdl.edu.mx', 2, 1, 'DELGADILLO GOMEZ LUZ MARIA', '2023-05-24 19:17:37', NULL),
(286, 'cesar.delgado@docente.univer-gdl.edu.mx', 2, 1, 'DELGADO ALONSO CESAR ADRIAN', '2023-05-24 19:17:37', NULL),
(287, 'carlos.delgado@docente.univer-gdl.edu.mx', 2, 1, 'DELGADO RIOS CARLOS ALBERTO', '2023-05-24 19:17:37', NULL),
(288, 'julio.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ HERNANDEZ JULIO', '2023-05-24 19:17:37', NULL),
(289, 'gerardo.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ LUNA GERARDO', '2023-05-24 19:17:37', NULL),
(290, 'jacqueline.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ RAMIREZ JACQUELINE MONSERRAT', '2023-05-24 19:17:38', NULL),
(291, 'ruben.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ RODRIGUEZ RUBEN FRANCISCO', '2023-05-24 19:17:38', NULL),
(292, 'abraham.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ SANCHEZ ABRAHAM', '2023-05-24 19:17:38', NULL),
(293, 'luz.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ SANCHEZ LUZ MARIA', '2023-05-24 19:17:38', NULL),
(294, 'josefina.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DIAZ TREJO JOSEFINA', '2023-05-24 19:17:38', NULL),
(295, 'jorge.dominguez@docente.univer-gdl.edu.mx', 2, 1, 'DOMINGUEZ FLORES JORGE DANIEL', '2023-05-24 19:17:38', NULL),
(296, 'cesar.dominguez@docente.univer-gdl.edu.mx', 2, 1, 'DOMINGUEZ MARTINEZ CESAR ENRIQUE', '2023-05-24 19:17:38', NULL),
(297, 'daniel.dominguez@docente.univer-gdl.edu.mx', 2, 1, 'DOMINGUEZ PUENTE DANIEL', '2023-05-24 19:17:38', NULL),
(298, 'erick.escobar@docente.univer-gdl.edu.mx', 2, 1, 'ESCOBAR SILIAS ERICK EDUARDO', '2023-05-24 19:17:38', NULL),
(299, 'selene.espinosa@docente.univer-gdl.edu.mx', 2, 1, 'ESPINOSA MARTINEZ SELENE', '2023-05-24 19:17:38', NULL),
(300, 'janeth.espinosa@docente.univer-gdl.edu.mx', 2, 1, 'ESPINOSA SOLIS JANETH', '2023-05-24 19:17:38', NULL),
(301, 'carlos.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'ESPINOZA DURAN CARLOS', '2023-05-24 19:17:38', NULL),
(302, 'leonel.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'ESPINOZA DURAN LEONEL', '2023-05-24 19:17:38', NULL),
(303, 'maria.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'ESPINOZA MARTINEZ MARIA DEL CARMEN', '2023-05-24 19:17:38', NULL),
(304, 'emmanuel.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'ESPINOZA ROBLES EMMANUEL GUADALUPE', '2023-05-24 19:17:39', NULL),
(305, 'pablo.estrada@docente.univer-gdl.edu.mx', 2, 1, 'ESTRADA DURAN PABLO OCTAVIO', '2023-05-24 19:17:39', NULL),
(306, 'maria.fernandez@docente.univer-gdl.edu.mx', 2, 1, 'FERNANDEZ GARCIA MARIA DEL CARMEN', '2023-05-24 19:17:39', NULL),
(307, 'patricia.figueroa@docente.univer-gdl.edu.mx', 2, 1, 'FIGUEROA CHAVEZ PATRICIA GUADALUPE', '2023-05-24 19:17:39', NULL),
(308, 'concepcion.flores@docente.univer-gdl.edu.mx', 2, 1, 'FLORES DE LA TORRE CONCEPCION MARGARITA', '2023-05-24 19:17:39', NULL),
(309, 'rocio.flores@docente.univer-gdl.edu.mx', 2, 1, 'FLORES GUTIERREZ ROCIO EDITH', '2023-05-24 19:17:39', NULL),
(310, 'pedro.flores@docente.univer-gdl.edu.mx', 2, 1, 'FLORES LARA PEDRO ALBERTO', '2023-05-24 19:17:39', NULL),
(311, 'alejandro.flores@docente.univer-gdl.edu.mx', 2, 1, 'FLORES NIETO ALEJANDRO', '2023-05-24 19:17:39', NULL),
(312, 'lorena.flores@docente.univer-gdl.edu.mx', 2, 1, 'FLORES VAZQUEZ LORENA CAROLINA', '2023-05-24 19:17:39', NULL),
(313, 'diana.galan@docente.univer-gdl.edu.mx', 2, 1, 'GALAN VELAZQUEZ DIANA LIZETTE', '2023-05-24 19:17:39', NULL),
(314, 'rosario.gallegos@docente.univer-gdl.edu.mx', 2, 1, 'GALLEGOS DIAZ ROSARIO', '2023-05-24 19:17:39', NULL),
(315, 'sandra.galvan@docente.univer-gdl.edu.mx', 2, 1, 'GALVAN MORALES SANDRA LORENA', '2023-05-24 19:17:39', NULL),
(316, 'victoria.galvan@docente.univer-gdl.edu.mx', 2, 1, 'GALVAN OROZCO VICTORIA MARCELA', '2023-05-24 19:17:39', NULL),
(317, 'christian.garay@docente.univer-gdl.edu.mx', 2, 1, 'GARAY VEGA CHRISTIAN ISIDRO', '2023-05-24 19:17:39', NULL),
(318, 'adrian.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA ARANA JOSE ADRIAN', '2023-05-24 19:17:39', NULL),
(319, 'juan.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA DAMIAN JUAN MANUEL', '2023-05-24 19:17:39', NULL),
(320, 'francisco.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA ESPINOSA FRANCISCO JAVIER', '2023-05-24 19:17:39', NULL),
(321, 'teodoro.figueroa@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA FIGUEROA TEODORO', '2023-05-24 19:17:39', NULL),
(322, 'lourdes.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA GARCIA LOURDES GABRIELA', '2023-05-24 19:17:39', NULL),
(323, 'elda.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA GONZALEZ ELDA SANDYBEL', '2023-05-24 19:17:39', NULL),
(324, 'joaquin.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA HERNANDEZ JOAQUIN IGNACIO', '2023-05-24 19:17:40', NULL),
(325, 'martin.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA LIRA MARTIN DE JESUS', '2023-05-24 19:17:40', NULL),
(326, 'amelia.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA MUÃOZ AMELIA MAYELA', '2023-05-24 19:17:40', NULL),
(327, 'aldo.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA ORTIZ ALDO DANTE', '2023-05-24 19:17:40', NULL),
(328, 'brianda.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA PADILLA BRIANDA GABRIELA', '2023-05-24 19:17:40', NULL),
(329, 'luis.garcia@univer-gdl.edu.mx', 2, 1, 'GARCIA RAIGOSA LUIS ANTONIO', '2023-05-24 19:17:40', NULL),
(330, 'jose.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA RODRIGUEZ JOSE ARMANDO GERARDO', '2023-05-24 19:17:40', NULL),
(331, 'marlene.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA RODRIGUEZ MARLENE', '2023-05-24 19:17:40', NULL),
(332, 'julio.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA SANCHEZ JULIO', '2023-05-24 19:17:40', NULL),
(333, 'martha.garcia@univer-gdl.edu.mx', 2, 1, 'GARCIA SORIANO MARTHA MARIA DE JESUS', '2023-05-24 19:17:40', NULL),
(334, 'abel.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA ZAMORA ABEL', '2023-05-24 19:17:40', NULL),
(335, 'saul.garcia@docente.univer-gdl.edu.mx', 2, 1, 'GARCIA ZAÃUDO SAUL ARTURO', '2023-05-24 19:17:40', NULL),
(336, 'jaime.moreno@docente.univer-gdl.edu.mx', 2, 1, 'GARIBAY MORENO JAIME ARTURO', '2023-05-24 19:17:40', NULL),
(337, 'jorge.garza@docente.univer-gdl.edu.mx', 2, 1, 'GARZA TORRES JORGE ALBERTO', '2023-05-24 19:17:40', NULL),
(338, 'roberto.garza@docente.univer-gdl.edu.mx', 2, 1, 'GARZA WELSH RIVERA ROBERTO JONATHAN', '2023-05-24 19:17:40', NULL),
(339, 'daniel.godina@docente.univer-gdl.edu.mx', 2, 1, 'GODINA DUPOUX DANIEL CESAR', '2023-05-24 19:17:40', NULL),
(340, 'beatriz.godinez@docente.univer-gdl.edu.mx', 2, 1, 'GODINEZ CASTILLO BEATRIZ GUADALUPE', '2023-05-24 19:17:40', NULL),
(341, 'ana.gomez@docente.univer-gdl.edu.mx', 2, 1, 'GOMEZ CARRILLO ANA CHRISTIAN DEL CARMEN', '2023-05-24 19:17:40', NULL),
(342, 'daniel.gomez@docente.univer-gdl.edu.mx', 2, 1, 'GOMEZ HERNANDEZ DANIEL', '2023-05-24 19:17:41', NULL),
(343, 'cristina.gomez@docente.univer-gdl.edu.mx', 2, 1, 'GOMEZ RIVERA CRISTINA ALEJANDRA', '2023-05-24 19:17:41', NULL),
(344, 'david.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'GOMEZ RODRIGUEZ DAVID', '2023-05-24 19:17:41', NULL),
(345, 'santos.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ ALVAREZ SANTOS ANTONIO', '2023-05-24 19:17:41', NULL),
(346, 'martha.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ CINCO MARTHA LETICIA', '2023-05-24 19:17:41', NULL),
(347, 'miguel.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ CONTRERAS MIGUEL ANGEL', '2023-05-24 19:17:41', NULL),
(348, 'jose.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ GONZALEZ JOSE DE JESUS', '2023-05-24 19:17:41', NULL),
(349, 'javier.pintor@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ PINTOR FRANCISCO JAVIER', '2023-05-24 19:17:41', NULL),
(350, 'yesenia.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ REYES YESENIA ELIZABETH', '2023-05-24 19:17:41', NULL),
(351, 'christian.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ VAZQUEZ CHRISTIAN EDUARDO', '2023-05-24 19:17:41', NULL),
(352, 'celia.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ VILLAGRAN CELIA MARIA DE LA LUZ', '2023-05-24 19:17:41', NULL),
(353, 'cesar.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'GONZALEZ VILLAGRAN CESAR ALEJANDRO', '2023-05-24 19:17:41', NULL),
(354, 'patricia.guadarrama@docente.univer-gdl.edu.mx', 2, 1, 'GUADARRAMA HERNANDEZ PATRICIA MARGARITA', '2023-05-24 19:17:41', NULL),
(355, 'jose.guardado@docente.univer-gdl.edu.mx', 2, 1, 'GUARDADO TRUJILLO JOSE DE JESUS', '2023-05-24 19:17:41', NULL),
(356, 'jesus.guerra@docente.univer-gdl.edu.mx', 2, 1, 'GUERRA HERNANDEZ JESUS DANIEL', '2023-05-24 19:17:41', NULL),
(357, 'alex.guerrero@docente.univer-gdl.edu.mx', 2, 1, 'GUERRERO GOMEZ ALEX ALBERTO', '2023-05-24 19:17:41', NULL),
(358, 'luis.guerrero@docente.univer-gdl.edu.mx', 2, 1, 'GUERRERO SUAREZ LUIS HUMBERTO', '2023-05-24 19:17:41', NULL),
(359, 'socorro.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'GUTIERREZ ALARCON SOCORRO', '2023-05-24 19:17:41', NULL),
(360, 'edgar.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'GUTIERREZ GONZALEZ EDGAR', '2023-05-24 19:17:41', NULL),
(361, 'norma.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'GUTIERREZ MILIAN NORMA ANGELICA', '2023-05-24 19:17:41', NULL),
(362, 'beatriz.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'GUTIERREZ ORTEGA BEATRIZ HAYDE', '2023-05-24 19:17:42', NULL),
(363, 'nohemi.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'GUTIERREZ SALAZAR NOHEMI EDITH', '2023-05-24 19:17:42', NULL),
(364, 'araceli.guzman@docente.univer-gdl.edu.mx', 2, 1, 'GUZMAN RAMIREZ ARACELI', '2023-05-24 19:17:42', NULL),
(365, 'julio.haros@docente.univer-gdl.edu.mx', 2, 1, 'HAROS BECERRA JULIO HAMID', '2023-05-24 19:17:42', NULL),
(366, 'mayra.heredia@docente.univer-gdl.edu.mx', 2, 1, 'HEREDIA ESPINOZA MAYRA', '2023-05-24 19:17:42', NULL),
(367, 'alan.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ BECERRA ALAN JOSEPH', '2023-05-24 19:17:42', NULL),
(368, 'ogla.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ CASTRO OGLA', '2023-05-24 19:17:42', NULL),
(369, 'favio.cordova@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ CORDOVA FAVIO ALONSO', '2023-05-24 19:17:42', NULL),
(370, 'mara.cordova@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ CORDOVA MARA SABYLU', '2023-05-24 19:17:42', NULL),
(371, 'zulema.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ DOMINGUEZ ZULEMA', '2023-05-24 19:17:42', NULL),
(372, 'saul.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ GALLEGOS SAUL TEODORO', '2023-05-24 19:17:42', NULL),
(373, 'lucia.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ GUEVARA LUCIA', '2023-05-24 19:17:42', NULL),
(374, 'jorge.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ GUTIERREZ JORGE ALEJANDRO', '2023-05-24 19:17:42', NULL),
(375, 'magdalena.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ ORTIZ MA. MAGDALENA', '2023-05-24 19:17:42', NULL),
(376, 'julio.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'HERNANDEZ VALENCIA JULIO RAFAEL', '2023-05-24 19:17:42', NULL),
(377, 'alma.herrera@docente.univer-gdl.edu.mx', 2, 1, 'HERRERA YERENA ALMA LETICIA', '2023-05-24 19:17:42', NULL),
(378, 'ernesto.hinojosa@docente.univer-gdl.edu.mx', 2, 1, 'HINOJOSA AMOZURRUTIA ERNESTO', '2023-05-24 19:17:42', NULL),
(379, 'victor.huerta@docente.univer-gdl.edu.mx', 2, 1, 'HUERTA FRANCISCO VICTOR ALBERTO', '2023-05-24 19:17:43', NULL),
(380, 'pedro.ibarra@docente.univer-gdl.edu.mx', 2, 1, 'IBARRA LOPEZ PEDRO', '2023-05-24 19:17:43', NULL),
(381, 'elvia.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'IÃIGUEZ GONZALEZ ELVIA INOCENCIA', '2023-05-24 19:17:43', NULL),
(382, 'laura.islas@docente.univer-gdl.edu.mx', 2, 1, 'ISLAS SOTO LAURA ESTELA', '2023-05-24 19:17:43', NULL),
(383, 'yolanda.jamit@docente.univer-gdl.edu.mx', 2, 1, 'JAMIT ANGELES YOLANDA', '2023-05-24 19:17:43', NULL),
(384, 'roberto.jara@docente.univer-gdl.edu.mx', 2, 1, 'JARA NAVARRETE ROBERTO', '2023-05-24 19:17:43', NULL),
(385, 'adriana.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'JIMENEZ BECERRA ADRIANA', '2023-05-24 19:17:43', NULL),
(386, 'aide.azucena@docente.univer-gdl.edu.mx', 2, 1, 'JIMENEZ GONZALEZ AIDE AZUCENA', '2023-05-24 19:17:43', NULL),
(387, 'salvador.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'JIMENEZ RUIZ SALVADOR', '2023-05-24 19:17:43', NULL),
(388, 'gerardo.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'JIMENEZ SOLORIO GERARDO ANTONIO', '2023-05-24 19:17:43', NULL),
(389, 'efren.joaquin@docente.univer-gdl.edu.mx', 2, 1, 'JOAQUIN RUELAS EFREN', '2023-05-24 19:17:43', NULL),
(390, 'gustavo.landey@docente.univer-gdl.edu.mx', 2, 1, 'LANDEY ROMAN GUSTAVO', '2023-05-24 19:17:43', NULL),
(391, 'rosa.leal@docente.univer-gdl.edu.mx', 2, 1, 'LEAL HERMOSILLO ROSA MARIA', '2023-05-24 19:17:43', NULL),
(392, 'diego.leon@docente.univer-gdl.edu.mx', 2, 1, 'LEON SILVA DIEGO DE JESUS', '2023-05-24 19:17:43', NULL),
(393, 'luis.lezama@docente.univer-gdl.edu.mx', 2, 1, 'LEZAMA GUTIERREZ LUIS RODRIGO', '2023-05-24 19:17:43', NULL),
(394, 'maria.limon@docente.univer-gdl.edu.mx', 2, 1, 'LIMON AGUILAR MARIA ELIZABETH', '2023-05-24 19:17:44', NULL),
(395, 'miguel.lizarraga@docente.univer-gdl.edu.mx', 2, 1, 'LIZARRAGA BETANCOURT MIGUEL ANGEL', '2023-05-24 19:17:44', NULL),
(396, 'carlos.llamas@docente.univer-gdl.edu.mx', 2, 1, 'LLAMAS MERCADO CARLOS ROSENDO', '2023-05-24 19:17:44', NULL),
(397, 'paola.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ ACERO PAOLA ROXY', '2023-05-24 19:17:44', NULL),
(398, 'prospero.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ DELGADO PROSPERO', '2023-05-24 19:17:44', NULL),
(399, 'marisol.lopezf@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ FLORES MARISOL', '2023-05-24 19:17:44', NULL),
(400, 'pablo.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ GONZALEZ PABLO CESAR', '2023-05-24 19:17:44', NULL),
(401, 'ivan.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ LOPEZ IVAN ANTONIO', '2023-05-24 19:17:44', NULL),
(402, 'jaquelin.lopez@univer-gdl.edu.mx', 2, 1, 'LOPEZ MAGAÃA YESSENIA JACQUELIN', '2023-05-24 19:17:44', NULL),
(403, 'fernando.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ MARTINEZ FERNANDO OCTAVIO', '2023-05-24 19:17:44', NULL),
(404, 'illyan.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ MERCADO ILLYAN IZTEL', '2023-05-24 19:17:44', NULL),
(405, 'jose.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ PLASCENCIA JOSE DE JESUS', '2023-05-24 19:17:44', NULL),
(406, 'francisco.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ RAMIREZ FRANCISCO', '2023-05-24 19:17:44', NULL),
(407, 'alejandro@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ SALINAS ALEJANDRO', '2023-05-24 19:17:44', NULL),
(408, 'luis.lopez@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ SALLES LUIS', '2023-05-24 19:17:44', NULL),
(409, 'luis.zambrano@docente.univer-gdl.edu.mx', 2, 1, 'LOPEZ ZAMBRANO LUIS ALFONSO', '2023-05-24 19:17:45', NULL),
(410, 'victor.loredo@docente.univer-gdl.edu.mx', 2, 1, 'LOREDO OJEDA VICTOR HUGO', '2023-05-24 19:17:45', NULL),
(411, 'jose.loza@docente.univer-gdl.edu.mx', 2, 1, 'LOZA AGUILAR JOSE JAVIER', '2023-05-24 19:17:45', NULL),
(412, 'juan.loza@docente.univer-gdl.edu.mx', 2, 1, 'LOZA CEDEÃO JUAN PABLO', '2023-05-24 19:17:45', NULL),
(413, 'fernando.lozano@docente.univer-gdl.edu.mx', 2, 1, 'LOZANO AMARAL FERNANDO EMETERIO', '2023-05-24 19:17:45', NULL),
(414, 'brenda.lozano@docente.univer-gdl.edu.mx', 2, 1, 'LOZANO FIGUEROA BRENDA NOEMI', '2023-05-24 19:17:45', NULL),
(415, 'rosa.luna@docente.univer-gdl.edu.mx', 2, 1, 'LUNA MARTINEZ ROSA ISELA', '2023-05-24 19:17:45', NULL),
(416, 'veronica.luna@docente.univer-gdl.edu.mx', 2, 1, 'LUNA MENDOZA VERONICA', '2023-05-24 19:17:45', NULL),
(417, 'carlos.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'MAGAÃA RAMIREZ CARLOS RAUL', '2023-05-24 19:17:45', NULL),
(418, 'gabriela.maraveles@docente.univer-gdl.edu.mx', 2, 1, 'MARAVELES TOVAR GABRIELA', '2023-05-24 19:17:45', NULL),
(419, 'roberto.marin@docente.univer-gdl.edu.mx', 2, 1, 'MARIN DE LA GARZA ROBERTO', '2023-05-24 19:17:45', NULL),
(420, 'mario.marin@docente.univer-gdl.edu.mx', 2, 1, 'MARIN TORRES MARIO', '2023-05-24 19:17:45', NULL),
(421, 'jose.mariscal@docente.univer-gdl.edu.mx', 2, 1, 'MARISCAL ORTIZ JOSE DE JESUS', '2023-05-24 19:17:45', NULL),
(422, 'magaly.marquez@univer-gdl.edu.mx', 2, 1, 'MARQUEZ CRUZ MARIA MAGALLY', '2023-05-24 19:17:45', NULL),
(423, 'daniel.aguilar@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ AGUILAR DANIEL', '2023-05-24 19:17:45', NULL),
(424, 'edwin.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ ARENAS EDWIN FERNANDO', '2023-05-24 19:17:45', NULL),
(425, 'francisco.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ MARTINEZ FRACISCO JAVIER', '2023-05-24 19:17:45', NULL),
(426, 'cesar.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ MEDINA CESAR ULISES', '2023-05-24 19:17:45', NULL),
(427, 'tania.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ PEREZ TANIA', '2023-05-24 19:17:46', NULL),
(428, 'martha.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ RAMIREZ MARTHA LETICIA', '2023-05-24 19:17:46', NULL),
(429, 'ma.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ REYNOSA MA LUZ', '2023-05-24 19:17:46', NULL),
(430, 'miriam.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MARTINEZ VALDEZ MIRIAM ALELHY', '2023-05-24 19:17:46', NULL),
(431, 'carlos.mata@docente.univer-gdl.edu.mx', 2, 1, 'MATA CARRILLO CARLOS FRANCISCO', '2023-05-24 19:17:46', NULL),
(432, 'esmeralda.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'MATA GUTIERREZ ESMERALDA', '2023-05-24 19:17:46', NULL),
(433, 'javier.medina@docente.univer-gdl.edu.mx', 2, 1, 'MEDINA RAMOS JAVIER ABIGAIL', '2023-05-24 19:17:46', NULL),
(434, 'mayda.melendrez@docente.univer-gdl.edu.mx', 2, 1, 'MELENDREZ DIAZ MAYDA', '2023-05-24 19:17:46', NULL),
(435, 'luis.mendez@docente.univer-gdl.edu.mx', 2, 1, 'MENDEZ RUIZ LUIS BENJAMIN', '2023-05-24 19:17:46', NULL),
(436, 'monica.mendoza@docente.univer-gdl.edu.mx', 2, 1, 'MENDOZA FLORES MONICA JEANETTE', '2023-05-24 19:17:46', NULL),
(437, 'jose.meza@docente.univer-gdl.edu.mx', 2, 1, 'MEZA MACIEL JOSE ANTONIO', '2023-05-24 19:17:46', NULL),
(438, 'cynthia.meza@docente.univer-gdl.edu.mx', 2, 1, 'MEZA OROZCO CYNTHIA LIZETTE', '2023-05-24 19:17:46', NULL),
(439, 'sanjuana.meza@docente.univer-gdl.edu.mx', 2, 1, 'MEZA VELAZQUEZ SANJUANA VERONICA', '2023-05-24 19:17:46', NULL),
(440, 'carina.michel@docente.univer-gdl.edu.mx', 2, 1, 'MICHEL AGUILAR CARINA', '2023-05-24 19:17:46', NULL),
(441, 'aldo.moncayo@docente.univer-gdl.edu.mx', 2, 1, 'MONCAYO DAVALOS ALDO BERTIN', '2023-05-24 19:17:46', NULL),
(442, 'salazar.montes@docente.univer-gdl.edu.mx', 2, 1, 'MONTES DE OCA SALAZAR ROBERTO', '2023-05-24 19:17:46', NULL),
(443, 'juan.montes@docente.univer-gdl.edu.mx', 2, 1, 'MONTES RODRIGUEZ JUAN MANUEL', '2023-05-24 19:17:47', NULL),
(444, 'fausto.montes@docente.univer-gdl.edu.mx', 2, 1, 'MONTES SANCHEZ FAUSTO', '2023-05-24 19:17:47', NULL),
(445, 'jesus.montoya@docente.univer-gdl.edu.mx', 2, 1, 'MONTOYA VAZQUEZ JESUS FRANCISCO', '2023-05-24 19:17:47', NULL),
(446, 'monica.morales@docente.univer-gdl.edu.mx', 2, 1, 'MORALES TELLEZ MONICA DEL ROCIO', '2023-05-24 19:17:47', NULL),
(447, 'rene.morales@docente.univer-gdl.edu.mx', 2, 1, 'MORALES VARGAS RENE', '2023-05-24 19:17:47', NULL),
(448, 'luigi.mortola@docente.univer-gdl.edu.mx', 2, 1, 'MORTOLA VAZQUEZ LUIGI', '2023-05-24 19:17:47', NULL);
INSERT INTO `correos` (`id`, `correo`, `tipo`, `status`, `nombre`, `created_at`, `updated_at`) VALUES
(449, 'jose.munoz@docente.univer-gdl.edu.mx', 2, 1, 'MUÃOZ CORNEJO JOSE ANTONIO', '2023-05-24 19:17:47', NULL),
(450, 'lorena.fragoso@docente.univer-gdl.edu.mx', 2, 1, 'MUÃOZ FRAGOSO LORENA', '2023-05-24 19:17:47', NULL),
(451, 'liliana.quirarte@docente.univer-gdl.edu.mx', 2, 1, 'MUÃOZ QUIRARTE LILIANA DEL ROCIO', '2023-05-24 19:17:47', NULL),
(452, 'eduardo.najar@docente.univer-gdl.edu.mx', 2, 1, 'NAJAR CAZARES EDUARDO', '2023-05-24 19:17:47', NULL),
(453, 'dalia.napoles@docente.univer-gdl.edu.mx', 2, 1, 'NAPOLES DEL TORO DALIA', '2023-05-24 19:17:47', NULL),
(454, 'bruno.navarro@docente.univer-gdl.edu.mx', 2, 1, 'NAVARRO BARAJAS BRUNO ALBERTO', '2023-05-24 19:17:47', NULL),
(455, 'jose.navarro@docente.univer-gdl.edu.mx', 2, 1, 'NAVARRO MACIEL JOSE MANUEL', '2023-05-24 19:17:47', NULL),
(456, 'mayra.navarro@docente.univer-gdl.edu.mx', 2, 1, 'NAVARRO PADILLA MAYRA LIZETH', '2023-05-24 19:17:47', NULL),
(457, 'sandra.neri@docente.univer-gdl.edu.mx', 2, 1, 'NERI BALLESTEROS SANDRA FABIOLA', '2023-05-24 19:17:47', NULL),
(458, 'francisco.nunez@docente.univer-gdl.edu.mx', 2, 1, 'NUÃEZ MACIAS FRANCISCO JAVIER', '2023-05-24 19:17:47', NULL),
(459, 'lorena.nuno@docente.univer-gdl.edu.mx', 2, 1, 'NUÃO PALOMAR LORENA DE JESUS', '2023-05-24 19:17:47', NULL),
(460, 'edmundo.ochoa@docente.univer-gdl.edu.mx', 2, 1, 'OCHOA GALINA EDMUNDO', '2023-05-24 19:17:47', NULL),
(461, 'viviana.olivares@docente.univer-gdl.edu.mx', 2, 1, 'OLIVARES DELGADILLO VIVIANA COINTA', '2023-05-24 19:17:47', NULL),
(462, 'alfredo.olivarez@docente.univer-gdl.edu.mx', 2, 1, 'OLIVAREZ RAMIREZ ALFREDO', '2023-05-24 19:17:47', NULL),
(463, 'juan.olvera@docente.univer-gdl.edu.mx', 2, 1, 'OLVERA SALAZAR JUAN MANUEL', '2023-05-24 19:17:47', NULL),
(464, 'jose.orozco@docente.univer-gdl.edu.mx', 2, 1, 'OROZCO AGUILAR JOSE ANTONIO', '2023-05-24 19:17:48', NULL),
(465, 'rebeca.pulido@docente.univer-gdl.edu.mx', 2, 1, 'OROZCO PULIDO REBECA', '2023-05-24 19:17:48', NULL),
(466, 'martha.ortega@docente.univer-gdl.edu.mx', 2, 1, 'ORTEGA HERNANDEZ MARTHA ALICIA', '2023-05-24 19:17:48', NULL),
(467, 'maria.ortiz@docente.univer-gdl.edu.mx', 2, 1, 'ORTIZ GONZALEZ MARIA CECILIA', '2023-05-24 19:17:48', NULL),
(468, 'diego.ortiz@docente.univer-gdl.edu.mx', 2, 1, 'ORTIZ RIVERA DIEGO ALEJANDRO', '2023-05-24 19:17:48', NULL),
(469, 'raul.padilla@docente.univer-gdl.edu.mx', 2, 1, 'PADILLA ALONSO RAUL EDUARDO', '2023-05-24 19:17:48', NULL),
(470, 'oscar.palacios@docente.univer-gdl.edu.mx', 2, 1, 'PALACIOS CAMPA OSCAR DAVID', '2023-05-24 19:17:48', NULL),
(471, 'juan.pallares@docente.univer-gdl.edu.mx', 2, 1, 'PALLARES SAUZA JUAN PABLO', '2023-05-24 19:17:48', NULL),
(472, 'jesus.palomino@docente.univer-gdl.edu.mx', 2, 1, 'PALOMINO ESPARZA JESUS DAVID', '2023-05-24 19:17:48', NULL),
(473, 'arani.parra@docente.univer-gdl.edu.mx', 2, 1, 'PARRA PEREZ ARANI ELISA', '2023-05-24 19:17:48', NULL),
(474, 'judith.partida@docente.univer-gdl.edu.mx', 2, 1, 'PARTIDA ACOSTA JUDITH', '2023-05-24 19:17:48', NULL),
(475, 'guillermo.pech@docente.univer-gdl.edu.mx', 2, 1, 'PECH TORRES GUILLERMO EMMANUEL', '2023-05-24 19:17:48', NULL),
(476, 'victor.pedregal@docente.univer-gdl.edu.mx', 2, 1, 'PEDREGAL VALDES VICTOR MANUEL', '2023-05-24 19:17:48', NULL),
(477, 'luz.barradas@docente.univer-gdl.edu.mx', 2, 1, 'PELAYO BARRADAS LUZ MARIA', '2023-05-24 19:17:48', NULL),
(478, 'karen.pena@docente.univer-gdl.edu.mx', 2, 1, 'PEÃA PRECIADO KAREN ILIANA', '2023-05-24 19:17:48', NULL),
(479, 'hugo.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ AGRAZ HUGO JAVIER', '2023-05-24 19:17:48', NULL),
(480, 'raul.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ BRAMBILA RAUL', '2023-05-24 19:17:48', NULL),
(481, 'ramon.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ ENRIQUEZ RAMON ANGEL', '2023-05-24 19:17:48', NULL),
(482, 'marisela.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ GONZALEZ MARISELA', '2023-05-24 19:17:48', NULL),
(483, 'alejandro.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ GUTIERREZ ALEJANDRO', '2023-05-24 19:17:48', NULL),
(484, 'cristo.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ HUERTA CRISTO EDGAR EDUARDO', '2023-05-24 19:17:49', NULL),
(485, 'jose.mejia@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ MEJIA JOSE ISABEL', '2023-05-24 19:17:49', NULL),
(486, 'jorge.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ MIGONI JORGE', '2023-05-24 19:17:49', NULL),
(487, 'michel.perez@docente.univer-gdl.edu.mx', 2, 1, 'PEREZ VIZCARRA CHRISTIAN MICHEL', '2023-05-24 19:17:49', NULL),
(488, 'adriana.pimentel@docente.univer-gdl.edu.mx', 2, 1, 'PIMENTEL GONZALEZ ADRIANA ELIZABETH', '2023-05-24 19:17:49', NULL),
(489, 'renee.pineda@docente.univer-gdl.edu.mx', 2, 1, 'PINEDA OCAMPO RENEE FABIAN', '2023-05-24 19:17:49', NULL),
(490, 'esther.plascencia@docente.univer-gdl.edu.mx', 2, 1, 'PLASCENCIA PEREZ ESTHER ALEJANDRA', '2023-05-24 19:17:49', NULL),
(491, 'xochitl.perez@docente.univer-gdl.edu.mx', 2, 1, 'PLASCENCIA PEREZ XOCHITL AURORA', '2023-05-24 19:17:49', NULL),
(492, 'marco.prado@docente.univer-gdl.edu.mx', 2, 1, 'PRADO SOLANO MARCO ANTONIO', '2023-05-24 19:17:49', NULL),
(493, 'lidia.pulido@docente.univer-gdl.edu.mx', 2, 1, 'PULIDO ORNELAS LIDIA', '2023-05-24 19:17:49', NULL),
(494, 'juan.quevedo@docente.univer-gdl.edu.mx', 2, 1, 'QUEVEDO MEZA JUAN MANUEL', '2023-05-24 19:17:49', NULL),
(495, 'mario.quintal@docente.univer-gdl.edu.mx', 2, 1, 'QUINTAL PAREDES MARIO HUMBERTO', '2023-05-24 19:17:49', NULL),
(496, 'armando.quintanilla@docente.univer-gdl.edu.mx', 2, 1, 'QUINTANILLA LARA ARMANDO', '2023-05-24 19:17:49', NULL),
(497, 'guadalupe.quintanilla@docente.univer-gdl.edu.mx', 2, 1, 'QUINTANILLA MAGALLANES GUADALUPE CRISTINA', '2023-05-24 19:17:49', NULL),
(498, 'luis.quiroz@docente.univer-gdl.edu.mx', 2, 1, 'QUIROZ GARCIA LUIS CARLOS', '2023-05-24 19:17:49', NULL),
(499, 'andres.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ ARRIAGA ANDRES', '2023-05-24 19:17:49', NULL),
(500, 'venancio.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ CISNEROS VENANCIO OCTAVIO', '2023-05-24 19:17:49', NULL),
(501, 'diego.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ HERNANDEZ DIEGO', '2023-05-24 19:17:49', NULL),
(502, 'armando.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ LOPEZ ARMANDO', '2023-05-24 19:17:49', NULL),
(503, 'flor.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ MONTES FLOR ANAHI', '2023-05-24 19:17:49', NULL),
(504, 'laura.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ OLVERA LAURA ABISSADAI', '2023-05-24 19:17:50', NULL),
(505, 'hector.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'RAMIREZ TEJEDA HECTOR', '2023-05-24 19:17:50', NULL),
(506, 'cecilia.delgado@docente.univer-gdl.edu.mx', 2, 1, 'RAMOS DELGADO CECILIA', '2023-05-24 19:17:50', NULL),
(507, 'fernando.erazo@docente.univer-gdl.edu.mx', 2, 1, 'RANGEL ERAZO FERNANDO ALBERTO', '2023-05-24 19:17:50', NULL),
(508, 'roberto.rascon@docente.univer-gdl.edu.mx', 2, 1, 'RASCON MARTINEZ ROBERTO', '2023-05-24 19:17:50', NULL),
(509, 'alfonso.reyes@docente.univer-gdl.edu.mx', 2, 1, 'REYES JIMENEZ ALFONSO', '2023-05-24 19:17:50', NULL),
(510, 'juan.reyes@docente.univer-gdl.edu.mx', 2, 1, 'REYES SOLARES JUAN CARLOS', '2023-05-24 19:17:50', NULL),
(511, 'elizabeth.reyna@docente.univer-gdl.edu.mx', 2, 1, 'REYNA ESTRADA ELIZABETH', '2023-05-24 19:17:50', NULL),
(512, 'jose.robles@docente.univer-gdl.edu.mx', 2, 1, 'ROBLES ALBA JOSE JAIR', '2023-05-24 19:17:50', NULL),
(513, 'francisco.robles@docente.univer-gdl.edu.mx', 2, 1, 'ROBLES OLIVA FRANCISCO JAVIER', '2023-05-24 19:17:50', NULL),
(514, 'eduardo.rodarte@docente.univer-gdl.edu.mx', 2, 1, 'RODARTE ELIZARRARAS EDUARDO', '2023-05-24 19:17:50', NULL),
(515, 'hector.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ ANDALON HECTOR MANUEL', '2023-05-24 19:17:50', NULL),
(516, 'oscar.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ BARBOSA OSCAR MANUEL', '2023-05-24 19:17:50', NULL),
(517, 'maria.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ ESQUIVEL MARIA DEL ROSARIO', '2023-05-24 19:17:50', NULL),
(518, 'enrique.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ HERNANDEZ ENRIQUE', '2023-05-24 19:17:50', NULL),
(519, 'mario.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ MUÃIZ MARIO', '2023-05-24 19:17:50', NULL),
(520, 'araceli.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ NUÃEZ ARACELI', '2023-05-24 19:17:50', NULL),
(521, 'ramon.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'RODRIGUEZ SOTO RAMON DANIEL', '2023-05-24 19:17:50', NULL),
(522, 'joaquin.romero@docente.univer-gdl.edu.mx', 2, 1, 'ROMERO JIMENEZ JOAQUIN', '2023-05-24 19:17:51', NULL),
(523, 'maria.romero@docente.univer-gdl.edu.mx', 2, 1, 'ROMERO LEYVA MARIA DOLORES', '2023-05-24 19:17:51', NULL),
(524, 'jessica.romero@docente.univer-gdl.edu.mx', 2, 1, 'ROMERO RAMIREZ JESSICA GABRIELA', '2023-05-24 19:17:51', NULL),
(525, 'miguel.perez@docente.univer-gdl.edu.mx', 2, 1, 'ROSADO PEREZ MIGUEL MARTIN', '2023-05-24 19:17:51', NULL),
(526, 'nayeli.rosales@docente.univer-gdl.edu.mx', 2, 1, 'ROSALES LUNA NAYELI MARISOL', '2023-05-24 19:17:51', NULL),
(527, 'maria.rosas@docente.univer-gdl.edu.mx', 2, 1, 'ROSAS ARANDA MARIA VIVIANA', '2023-05-24 19:17:51', NULL),
(528, 'jose.rosas@docente.univer-gdl.edu.mx', 2, 1, 'ROSAS GARCIA JOSE ANGEL', '2023-05-24 19:17:51', NULL),
(529, 'carlos.rubio@docente.univer-gdl.edu.mx', 2, 1, 'RUBIO GARAY CARLOS ERNESTO', '2023-05-24 19:17:51', NULL),
(530, 'raul.ruelas@docente.univer-gdl.edu.mx', 2, 1, 'RUELAS SILVA RAUL', '2023-05-24 19:17:51', NULL),
(531, 'luis.rivas@docente.univer-gdl.edu.mx', 2, 1, 'RUISANCHEZ RIVAS LUIS ROBERTO', '2023-05-24 19:17:51', NULL),
(532, 'pedro.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'RUIZ LUGO PEDRO OMAR', '2023-05-24 19:17:51', NULL),
(533, 'anasol.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'RUIZ RUIZ ANASOL', '2023-05-24 19:17:51', NULL),
(534, 'mercedes.saavedra@docente.univer-gdl.edu.mx', 2, 1, 'SAAVEDRA JIMENEZ MERCEDES IRENE', '2023-05-24 19:17:51', NULL),
(535, 'maria.salaman@docente.univer-gdl.edu.mx', 2, 1, 'SALAMAN REYNOSO MARIA GEORGINA', '2023-05-24 19:17:52', NULL),
(536, 'maria.salazar@docente.univer-gdl.edu.mx', 2, 1, 'SALAZAR GARCIA MA. DEL CARMEN', '2023-05-24 19:17:52', NULL),
(537, 'claudia.salazar@docente.univer-gdl.edu.mx', 2, 1, 'SALAZAR GOMEZ CLAUDIA ISABEL', '2023-05-24 19:17:52', NULL),
(538, 'rodrigo.salazar@docente.univer-gdl.edu.mx', 2, 1, 'SALAZAR MENDOZA RODRIGO', '2023-05-24 19:17:52', NULL),
(539, 'bertha.saldana@docente.univer-gdl.edu.mx', 2, 1, 'SALDAÃA PEREZ BERTHA ALICIA', '2023-05-24 19:17:52', NULL),
(540, 'saul.salgado@docente.univer-gdl.edu.mx', 2, 1, 'SALGADO GONZALEZ SAUL ANTONIO', '2023-05-24 19:17:52', NULL),
(541, 'pedro.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'SANCHEZ HEREDIA PEDRO', '2023-05-24 19:17:52', NULL),
(542, 'graciela.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'SANCHEZ MARTINEZ GRACIELA', '2023-05-24 19:17:52', NULL),
(543, 'orietta.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'SANCHEZ ROMAN ORIETTA', '2023-05-24 19:17:52', NULL),
(544, 'arnulfo.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'SANCHEZ SUAREZ ARNULFO', '2023-05-24 19:17:52', NULL),
(545, 'ricardo.sandoval@docente.univer-gdl.edu.mx', 2, 1, 'SANDOVAL CASTRO RICARDO', '2023-05-24 19:17:52', NULL),
(546, 'filiberto.santiago@docente.univer-gdl.edu.mx', 2, 1, 'SANTIAGO NAVA FILIBERTO', '2023-05-24 19:17:52', NULL),
(547, 'sergio.santos@docente.univer-gdl.edu.mx', 2, 1, 'SANTOS JORDAN SERGIO ALBERTO', '2023-05-24 19:17:52', NULL),
(548, 'jorge.santoyo@docente.univer-gdl.edu.mx', 2, 1, 'SANTOYO ORENDAIN JORGE RAMON', '2023-05-24 19:17:52', NULL),
(549, 'victor.monreal@docente.univer-gdl.edu.mx', 2, 1, 'SAUCEDO MONREAL VICTOR MANUEL', '2023-05-24 19:17:52', NULL),
(550, 'mario.segoviano@docente.univer-gdl.edu.mx', 2, 1, 'SEGOVIANO GUTIERREZ MARIO ARTURO', '2023-05-24 19:17:53', NULL),
(551, 'cecati.97@docente.univer-gdl.edu.mx', 2, 1, 'SEP CECATI 97', '2023-05-24 19:17:53', NULL),
(552, 'catalina.solares@univer-gdl.edu.mx', 2, 1, 'SOLARES PEÃA CATALINA', '2023-05-24 19:17:53', NULL),
(553, 'humberto.solis@docente.univer-gdl.edu.mx', 2, 1, 'SOLIS DE LA CERDA HUMBERTO ELIAS', '2023-05-24 19:17:53', NULL),
(554, 'maria.solis@docente.univer-gdl.edu.mx', 2, 1, 'SOLIS PEDROZA MARIA DE JESUS', '2023-05-24 19:17:53', NULL),
(555, 'maria.soltero@docente.univer-gdl.edu.mx', 2, 1, 'SOLTERO LEDEZMA MARIA FERNANDA', '2023-05-24 19:17:53', NULL),
(556, 'claudia.soto@docente.univer-gdl.edu.mx', 2, 1, 'SOTO ROJAS CLAUDIA ROCIO', '2023-05-24 19:17:53', NULL),
(557, 'arturo.gomez@docente.univer-gdl.edu.mx', 2, 1, 'SOUZA GOMEZ ARTURO', '2023-05-24 19:17:53', NULL),
(558, 'villela.suarez@docente.univer-gdl.edu.mx', 2, 1, 'SUAREZ SANCHEZ VILLELA CLARA', '2023-05-24 19:17:53', NULL),
(559, 'alexandra.tineo@docente.univer-gdl.edu.mx', 2, 1, 'TINEO PERALES ALEXANDRA CAROLINA', '2023-05-24 19:17:53', NULL),
(560, 'jonathan.tornero@docente.univer-gdl.edu.mx', 2, 1, 'TORNERO GUTIERREZ JONATHAN ISHAIN', '2023-05-24 19:17:53', NULL),
(561, 'juan.torres@docente.univer-gdl.edu.mx', 2, 1, 'TORRES BORDALLO JUAN MANUEL', '2023-05-24 19:17:53', NULL),
(562, 'israel.torres@docente.univer-gdl.edu.mx', 2, 1, 'TORRES JACOBO ISRAEL', '2023-05-24 19:17:53', NULL),
(563, 'carlos.torres@docente.univer-gdl.edu.mx', 2, 1, 'TORRES LEAL CARLOS EMAHIN', '2023-05-24 19:17:53', NULL),
(564, 'aziel.torres@docente.univer-gdl.edu.mx', 2, 1, 'TORRES MARTINEZ AZIEL JOSAFAT', '2023-05-24 19:17:54', NULL),
(565, 'fermin.diaz@docente.univer-gdl.edu.mx', 2, 1, 'TREJO DIAZ FERMIN', '2023-05-24 19:17:54', NULL),
(566, 'juan.trillo@docente.univer-gdl.edu.mx', 2, 1, 'TRILLO GOMEZ GALLARDO JUAN PABLO', '2023-05-24 19:17:54', NULL),
(567, 'alma.chavez@docente.univer-gdl.edu.mx', 2, 1, 'UREÃA CHAVEZ ALMA DELIA', '2023-05-24 19:17:54', NULL),
(568, 'jessika.urena@docente.univer-gdl.edu.mx', 2, 1, 'UREÃA VALENZUELA JESSIKA ALEJANDRA', '2023-05-24 19:17:54', NULL),
(569, 'sandra.valdivia@docente.univer-gdl.edu.mx', 2, 1, 'VALDIVIA HERNANDEZ SANDRA PATRICIA', '2023-05-24 19:17:54', NULL),
(570, 'enrique.valdovinos@docente.univer-gdl.edu.mx', 2, 1, 'VALDOVINOS PORTILLO ENRIQUE', '2023-05-24 19:17:54', NULL),
(571, 'alfredo.valenciae@docente.univer-gdl.edu.mx', 2, 1, 'VALENCIA ESTRADA ALFREDO', '2023-05-24 19:17:54', NULL),
(572, 'alfredo.valencia@docente.univer-gdl.edu.mx', 2, 1, 'VALENCIA HARO ALFREDO', '2023-05-24 19:17:54', NULL),
(573, 'carlos.valle@docente.univer-gdl.edu.mx', 2, 1, 'VALLE MALDONADO CARLOS YAIR', '2023-05-24 19:17:54', NULL),
(574, 'miguel.valle@docente.univer-gdl.edu.mx', 2, 1, 'VALLE ROBLES MIGUEL ANGEL', '2023-05-24 19:17:55', NULL),
(575, 'miguel.vargas@docente.univer-gdl.edu.mx', 2, 1, 'VARGAS IBARRA MIGUEL ANGEL', '2023-05-24 19:17:55', NULL),
(576, 'antonio.vargas@docente.univer-gdl.edu.mx', 2, 1, 'VARGAS MORENO ANTONIO SEBASTIAN', '2023-05-24 19:17:55', NULL),
(577, 'gabriela.vazquez@docente.univer-gdl.edu.mx', 2, 1, 'VAZQUEZ RODRIGUEZ GABRIELA', '2023-05-24 19:17:55', NULL),
(578, 'yolanda.velazquez@docente.univer-gdl.edu.mx', 2, 1, 'VELAZQUEZ PALLARES YOLANDA AMALIA', '2023-05-24 19:17:55', NULL),
(579, 'cynthia.velazquez@docente.univer-gdl.edu.mx', 2, 1, 'VELAZQUEZ VALENZUELA CYNTHIA', '2023-05-24 19:17:55', NULL),
(580, 'juan.vera@docente.univer-gdl.edu.mx', 2, 1, 'VERA DE LA CRUZ JUAN ANTONIO', '2023-05-24 19:17:55', NULL),
(581, 'rafael.vera@docente.univer-gdl.edu.mx', 2, 1, 'VERA GLORIA RAFAEL', '2023-05-24 19:17:55', NULL),
(582, 'juan.vergara@docente.univer-gdl.edu.mx', 2, 1, 'VERGARA MORENO JUAN PABLO', '2023-05-24 19:17:55', NULL),
(583, 'cesar.villa@docente.univer-gdl.edu.mx', 2, 1, 'VILLA TORRES CESAR', '2023-05-24 19:17:56', NULL),
(584, 'rubi.martinez@docente.univer-gdl.edu.mx', 2, 1, 'VILLALOBOS MARTINEZ LILIANA RUBI', '2023-05-24 19:17:56', NULL),
(585, 'patricia.villalobos@docente.univer-gdl.edu.mx', 2, 1, 'VILLALOBOS MARTINEZ PATRICIA', '2023-05-24 19:17:56', NULL),
(586, 'jorge.cordero@docente.univer-gdl.edu.mx', 2, 1, 'VILLANUEVA CORDERO JORGE', '2023-05-24 19:17:56', NULL),
(587, 'luz.cordero@docente.univer-gdl.edu.mx', 2, 1, 'VILLANUEVA CORDERO LUZ ELENA', '2023-05-24 19:17:56', NULL),
(588, 'dulce.villarreal@docente.univer-gdl.edu.mx', 2, 1, 'VILLARREAL ESPINOZA DULCE MARILYN', '2023-05-24 19:17:57', NULL),
(589, 'alfonso.villasenor@docente.univer-gdl.edu.mx', 2, 1, 'VILLASEÃOR DIAZ ALFONSO', '2023-05-24 19:17:57', NULL),
(590, 'juan.zagaceta@docente.univer-gdl.edu.mx', 2, 1, 'ZAGACETA GARCIA JUAN CARLOS', '2023-05-24 19:17:57', NULL),
(591, 'david.zambrano@docente.univer-gdl.edu.mx', 2, 1, 'ZAMBRANO IZQUIERDO DAVID JESUS', '2023-05-24 19:17:57', NULL),
(592, 'alecxiz.zaragoza@docente.univer-gdl.edu.mx', 2, 1, 'ZARAGOZA ACEVES ALECXIZ', '2023-05-24 19:17:57', NULL),
(593, 'julio.zarate@docente.univer-gdl.edu.mx', 2, 1, 'ZARATE NAVARRO JULIO CESAR', '2023-05-24 19:17:57', NULL),
(594, 'miguel.zarza@docente.univer-gdl.edu.mx', 2, 1, 'ZARZA MUÃOZ MIGUEL ANGEL', '2023-05-24 19:17:57', NULL),
(595, 'enrique.zepeda@docente.univer-gdl.edu.mx', 2, 1, 'ZEPEDA AVIÃA ENRIQUE', '2023-05-24 19:17:57', NULL),
(596, 'katia.castillon@docente.univer-gdl.edu.mx', 2, 1, 'katia.castillon@docente.univer-gdl.edu.mx', '2023-05-24 19:17:57', NULL),
(597, 'casandra.moreno@docente.univer-gdl.edu.mx', 2, 1, 'Casandra Jazmin Moreno NuÃ±ez', '2023-05-24 19:17:58', NULL),
(598, 'laura.elizondo@docente.univer-gdl.edu.mx', 2, 1, 'Laura Elizondo Melchor', '2023-05-24 19:17:58', NULL),
(599, 'hector.raygoza@docente.univer-gdl.edu.mx', 2, 1, 'HECTOR RAYGOZA CASTRO', '2023-05-24 19:17:58', NULL),
(600, 'cyntia.azamar@docente.univer-gdl.edu.mx', 2, 1, 'CYNTIA SARAI AZAMAR GUERRERO', '2023-05-24 19:17:58', NULL),
(601, 'leobardo.magana@docente.univer-gdl.edu.mx', 2, 1, 'LEOBARDO MAGAÃA CORBALÃ', '2023-05-24 19:17:58', NULL),
(602, 'alejandro.verdin@docente.univer-gdl.edu.mx', 2, 1, 'Alejandro Verdin Sanchez', '2023-05-24 19:17:58', NULL),
(603, 'salvador.bautista@docente.univer-gdl.edu.mx', 2, 1, 'Salvador Vladimir Bautista Ponce', '2023-05-24 19:17:58', NULL),
(604, 'monica.vazquez@docente.univer-gdl.edu.mx', 2, 1, 'Monica Verenice Vazquez Valle', '2023-05-24 19:17:58', NULL),
(605, 'maria.novoa@docente.univer-gdl.edu.mx', 2, 1, 'Maria Fernanda Novoa Hernandez', '2023-05-24 19:17:58', NULL),
(606, 'rosa.carmona@docente.univer-gdl.edu.mx', 2, 1, 'Rosa Pilar Carmona Escutia', '2023-05-24 19:17:58', NULL),
(607, 'maria.mendez@docente.univer-gdl.edu.mx', 2, 1, 'MarÃ­a Montserrat Mendez Jaime', '2023-05-24 19:17:58', NULL),
(608, 'gabriela.cisneros@docente.univer-gdl.edu.mx', 2, 1, 'GABRIELA CISNEROS JARQUIN', '2023-05-24 19:17:59', NULL),
(609, 'rafael.cedano@docente.univer-gdl.edu.mx', 2, 1, 'Rafael Francisco Cedano Ballesteros', '2023-05-24 19:17:59', NULL),
(610, 'tania.vina@docente.univer-gdl.edu.mx', 2, 1, 'Tania Paulina ViÃ±a Frias', '2023-05-24 19:17:59', NULL),
(611, 'amador.campos@docente.univer-gdl.edu.mx', 2, 1, 'AMADOR ROBERTO CAMPOS VALDEZ', '2023-05-24 19:17:59', NULL),
(612, 'victor.venegas@docente.univer-gdl.edu.mx', 2, 1, 'VICTOR ALEXIS VENEGAS MARTINEZ', '2023-05-24 19:18:00', NULL),
(613, 'daniel.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'DANIEL ALBERTO HERNANDEZ ISAIAS', '2023-05-24 19:18:00', NULL),
(614, 'laura.rivas@docente.univer-gdl.edu.mx', 2, 1, 'LAURA SELENE RIVAS MARTINEZ', '2023-05-24 19:18:00', NULL),
(615, 'silvia.becerra@docente.univer-gdl.edu.mx', 2, 1, 'SILVIA LORENA BECERRA CAMARENA', '2023-05-24 19:18:00', NULL),
(616, 'oswaldo.perez@docente.univer-gdl.edu.mx', 2, 1, 'OSWALDO ISRAEL PEREZ NUÃEZ', '2023-05-24 19:18:00', NULL),
(617, 'silvia.landazuri@docente.univer-gdl.edu.mx', 2, 1, 'SILVIA LANDAZURI SANTOYO', '2023-05-24 19:18:00', NULL),
(618, 'angelica.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'ANGELICA GERALDIN GONZALEZ CELIS', '2023-05-24 19:18:00', NULL),
(619, 'mauricio.lopez@docente.univer-gdl.edu.mx', 2, 1, 'JOSE MAURICIO LOPEZ ITURRIOS', '2023-05-24 19:18:00', NULL),
(620, 'melany.vazquez@docente.univer-gdl.edu.mx', 2, 1, 'MELANY ARCELIA VAZQUEZ OCHOA', '2023-05-24 19:18:00', NULL),
(621, 'bertha.toscano@docente.univer-gdl.edu.mx', 2, 1, 'BERTHA TOSCANO ARCE', '2023-05-24 19:18:00', NULL),
(622, 'karen.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'KAREN ITZEL JIMENEZ MENDEZ', '2023-05-24 19:18:00', NULL),
(623, 'karla.flores@docente.univer-gdl.edu.mx', 2, 1, 'KARLA MARIA FLORES RUIZ', '2023-05-24 19:18:00', NULL),
(624, 'rodrigo.isabeles@docente.univer-gdl.edu.mx', 2, 1, 'Rodrigo Isabeles Osirio', '2023-05-24 19:18:00', NULL),
(625, 'francisco.marquez@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Alberto Marquez Corona', '2023-05-24 19:18:00', NULL),
(626, 'diego.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'Diego Salvador Jimenez Telles', '2023-05-24 19:18:01', NULL),
(627, 'kevin.pasos@docente.univer-gdl.edu.mx', 2, 1, 'Kevin Daniel Pasos Rivas', '2023-05-24 19:18:01', NULL),
(628, 'javier.zambrano@docente.univer-gdl.edu.mx', 2, 1, 'Javier Ramon Zambrano Melin', '2023-05-24 19:18:01', NULL),
(629, 'jose.diaz@docente.univer-gdl.edu.mx', 2, 1, 'Jose Alonso Diaz Ocon', '2023-05-24 19:18:01', NULL),
(630, 'elizabeth.pineda@docente.univer-gdl.edu.mx', 2, 1, 'Elizabeth Pineda Barajas', '2023-05-24 19:18:01', NULL),
(631, 'ramon.cordova@docente.univer-gdl.edu.mx', 2, 1, 'Ramon Perez Cordova', '2023-05-24 19:18:01', NULL),
(632, 'reynaldo.morales@docente.univer-gdl.edu.mx', 2, 1, 'Reynaldo Morales Hernandez', '2023-05-24 19:18:01', NULL),
(633, 'arturo.osorio@docente.univer-gdl.edu.mx', 2, 1, 'Arturo Osorio Mendez', '2023-05-24 19:18:01', NULL),
(634, 'heluet.vazquez@docente.univer-gdl.edu.mx', 2, 1, 'Heluet Kinnereth Vazquez Acosta', '2023-05-24 19:18:01', NULL),
(635, 'karla.velasco@docente.univer-gdl.edu.mx', 2, 1, 'Karla Leticia Velasco Rodriguez', '2023-05-24 19:18:01', NULL),
(636, 'bernardo.fuentes@docente.univer-gdl.edu.mx', 2, 1, 'Bernardo JosÃ© Fuentes Chirinos', '2023-05-24 19:18:01', NULL),
(637, 'claudia.banuelos@docente.univer-gdl.edu.mx', 2, 1, 'Claudia Patricia BaÃ±uelos Romero', '2023-05-24 19:18:01', NULL),
(638, 'mariana.canseco@docente.univer-gdl.edu.mx', 2, 1, 'Mariana Canseco BÃ¡ez', '2023-05-24 19:18:01', NULL),
(639, 'manuel.mata@docente.univer-gdl.edu.mx', 2, 1, 'Manuel Oswaldo Mata Briones', '2023-05-24 19:18:01', NULL),
(640, 'julieta.dealba@docente.univer-gdl.edu.mx', 2, 1, 'Julieta De Alba Gonzalez', '2023-05-24 19:18:02', NULL),
(641, 'carlos.fernandez@docente.univer-gdl.edu.mx', 2, 1, 'Carlos Alejandro Fernandez Rodriguez', '2023-05-24 19:18:02', NULL),
(642, 'silvia.calderon@docente.univer-gdl.edu.mx', 2, 1, 'Silvia Guillermina Calderon Garcia', '2023-05-24 19:18:02', NULL),
(643, 'enrique.perez@univer-gdl.edu.mx', 2, 1, 'Jose Enrique Perez Ramos', '2023-05-24 19:18:02', NULL),
(644, 'nancy.velazquez@univer-gdl.edu.mx', 2, 1, 'Nancy SofÃ­a VelÃ¡zquez Sandoval', '2023-05-24 19:18:02', NULL),
(645, 'daniel.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Daniel Lopez Ulloa', '2023-05-24 19:18:02', NULL),
(646, 'khristhyam.perez@docente.univer-gdl.edu.mx', 2, 1, 'Khristhyam Perez Medina', '2023-05-24 19:18:02', NULL),
(647, 'ruth.fregoso@docente.univer-gdl.edu.mx', 2, 1, 'Ruth Fregoso Sanchez', '2023-05-24 19:18:02', NULL),
(648, 'laura.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Laura Guillermina Sanchez Solano', '2023-05-24 19:18:02', NULL),
(649, 'ignacio.barron@docente.univer-gdl.edu.mx', 2, 1, 'Ignacio Alejandro Barron Torres', '2023-05-24 19:18:02', NULL),
(650, 'rosa.padilla@docente.univer-gdl.edu.mx', 2, 1, 'Rosa Alejandra Padilla Contreras', '2023-05-24 19:18:02', NULL),
(651, 'antonio.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'Antonio Hernandez Chavez', '2023-05-24 19:18:02', NULL),
(652, 'miriam.arellano@docente.univer-gdl.edu.mx', 2, 1, 'Miriam Cristina Arellano BaÃ±uelos', '2023-05-24 19:18:02', NULL),
(653, 'alfonso.perez@docente.univer-gdl.edu.mx', 2, 1, 'Alfonso Perez Gonzalez', '2023-05-24 19:18:02', NULL),
(654, 'karina.rojano@docente.univer-gdl.edu.mx', 2, 1, 'Karina Rojano Barajas', '2023-05-24 19:18:02', NULL),
(655, 'rosa.madrigal@docente.univer-gdl.edu.mx', 2, 1, 'Rosa Maria Madrigal Garcia', '2023-05-24 19:18:03', NULL),
(656, 'noel.franco@docente.univer-gdl.edu.mx', 2, 1, 'Noel Noe Franco Arroyo', '2023-05-24 19:18:03', NULL),
(657, 'elizabeth.corona@docente.univer-gdl.edu.mx', 2, 1, 'Elizabeth Corona Rodriguez', '2023-05-24 19:18:03', NULL),
(658, 'luis.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Luis Fernando Martinez Paez', '2023-05-24 19:18:03', NULL),
(659, 'cristian.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'Cristian Omar Hernandez Vazquez', '2023-05-24 19:18:03', NULL),
(660, 'elizabeth.baltazar@docente.univer-gdl.edu.mx', 2, 1, 'Elizabeth Baltazar Zepeda', '2023-05-24 19:18:03', NULL),
(661, 'saul.medel@docente.univer-gdl.edu.mx', 2, 1, 'Saul Antonio Medel Terrones', '2023-05-24 19:18:03', NULL),
(662, 'ilse.guareno@docente.univer-gdl.edu.mx', 2, 1, 'Ilse Betsabe GuareÃ±o Flores', '2023-05-24 19:18:03', NULL),
(663, 'gabriel.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Gabriel Rodriguez Valdez', '2023-05-24 19:18:03', NULL),
(664, 'adrian.islas@docente.univer-gdl.edu.mx', 2, 1, 'Adrian Islas Hernandez', '2023-05-24 19:18:03', NULL),
(665, 'victor.perez@docente.univer-gdl.edu.mx', 2, 1, 'Victor Hugo Perez Navarro', '2023-05-24 19:18:03', NULL),
(666, 'jairo.zamora@docente.univer-gdl.edu.mx', 2, 1, 'Jairo Ernesto Zamora Camarena', '2023-05-24 19:18:03', NULL),
(667, 'miguel.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Luis Miguel Lopez Camarena', '2023-05-24 19:18:04', NULL),
(668, 'daniel.jauregui@docente.univer-gdl.edu.mx', 2, 1, 'Daniel Jauregui Lopez', '2023-05-24 19:18:04', NULL),
(669, 'maritza.camacho@docente.univer-gdl.edu.mx', 2, 1, 'Maritza Isabel Camacho Valdez', '2023-05-24 19:18:04', NULL),
(670, 'belester.soberanis@docente.univer-gdl.edu.mx', 2, 1, 'Belester Soberanis Chavez', '2023-05-24 19:18:04', NULL),
(671, 'rosalba.veliz@docente.univer-gdl.edu.mx', 2, 1, 'Rosalba Veliz Tinoco', '2023-05-24 19:18:04', NULL),
(672, 'francisco.gauna@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Izcoatl Gauna Lopez', '2023-05-24 19:18:04', NULL),
(673, 'jonathan.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Jonathan Raul Lopez Carrion', '2023-05-24 19:18:04', NULL),
(674, 'teresita.serrano@docente.univer-gdl.edu.mx', 2, 1, 'Teresita De Jesus Serrano Luna', '2023-05-24 19:18:04', NULL),
(675, 'jesus.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'JesÃºs Martin Guadalupe Gonzalez Sanchez', '2023-05-24 19:18:04', NULL),
(676, 'elayne.romero@docente.univer-gdl.edu.mx', 2, 1, 'Elayne Baetriz Romero Montiel', '2023-05-24 19:18:05', NULL),
(677, 'ernesto.perez@docente.univer-gdl.edu.mx', 2, 1, 'Ernesto Alfredo Perez Becerra', '2023-05-24 19:18:05', NULL),
(678, 'jhonnatan.zavala@docente.univer-gdl.edu.mx', 2, 1, 'Jhonnatan Alejandro Zavala Lopez', '2023-05-24 19:18:05', NULL),
(679, 'brenda.curiel@docente.univer-gdl.edu.mx', 2, 1, 'Brenda Gisella Curiel Olague', '2023-05-24 19:18:05', NULL),
(680, 'sandra.rua@docente.univer-gdl.edu.mx', 2, 1, 'Sandra Hortencia Rua Hernandez', '2023-05-24 19:18:05', NULL),
(681, 'jose.curiel@docente.univer-gdl.edu.mx', 2, 1, 'Jose Curiel Reveles', '2023-05-24 19:18:05', NULL),
(682, 'adriana.quintero@docente.univer-gdl.edu.mx', 2, 1, 'Adriana Margarita Quintero Lopez', '2023-05-24 19:18:05', NULL),
(683, 'marcos.soto@docente.univer-gdl.edu.mx', 2, 1, 'Marcos Antonio Soto Rodriguez', '2023-05-24 19:18:05', NULL),
(684, 'luz.olguin@docente.univer-gdl.edu.mx', 2, 1, 'Luz Patricia Olguin Alvarez', '2023-05-24 19:18:05', NULL),
(685, 'gabriela.arce@docente.univer-gdl.edu.mx', 2, 1, 'Gabriela Josefina Arce Ochoa', '2023-05-24 19:18:06', NULL),
(686, 'miguel.castellanos@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Castellanos Lopez', '2023-05-24 19:18:06', NULL),
(687, 'nidia.banuelos@docente.univer-gdl.edu.mx', 2, 1, 'Nidia Beatriz BaÃ±uelos Hernandez', '2023-05-24 19:18:06', NULL),
(688, 'esteban.godinez@docente.univer-gdl.edu.mx', 2, 1, 'Esteban Godinez Mejia', '2023-05-24 19:18:06', NULL),
(689, 'kevin.almaraz@docente.univer-gdl.edu.mx', 2, 1, 'Kevin Josue Almaraz Ruano', '2023-05-24 19:18:06', NULL),
(690, 'diego.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Diego De Jesus Sanchez Rodriguez', '2023-05-24 19:18:06', NULL),
(691, 'evangelina.avalos@docente.univer-gdl.edu.mx', 2, 1, 'Evangelina Avalos Fernandez', '2023-05-24 19:18:06', NULL),
(692, 'lina.navejas@docente.univer-gdl.edu.mx', 2, 1, 'Lina Veronica Navejas Padilla', '2023-05-24 19:18:06', NULL),
(693, 'carlos.alvarez@docente.univer-gdl.edu.mx', 2, 1, 'Carlos Alberto Alvarez Alvarez', '2023-05-24 19:18:06', NULL),
(694, 'jesus.flores@docente.univer-gdl.edu.mx', 2, 1, 'Jesus Abraham Flores Gonzalez', '2023-05-24 19:18:06', NULL),
(695, 'mewy.manterola@docente.univer-gdl.edu.mx', 2, 1, 'Mewy Natalia Manterola Santa Maria', '2023-05-24 19:18:06', NULL),
(696, 'nayeli.salazar@docente.univer-gdl.edu.mx', 2, 1, 'Nayeli Del Carmen Salazar Urzua', '2023-05-24 19:18:07', NULL),
(697, 'juan.salinas@docente.univer-gdl.edu.mx', 2, 1, 'Juan Roberto Salinas Gomez', '2023-05-24 19:18:07', NULL),
(698, 'juan.valdes@docente.univer-gdl.edu.mx', 2, 1, 'Juan Carlos Valdes Jasso', '2023-05-24 19:18:07', NULL),
(699, 'laura.masso@docente.univer-gdl.edu.mx', 2, 1, 'Laura Sophia Masso Vargas', '2023-05-24 19:18:07', NULL),
(700, 'elsy.villa@docente.univer-gdl.edu.mx', 2, 1, 'Elsy Rocio Lizette Villa Fernandez', '2023-05-24 19:18:07', NULL),
(701, 'guadalupe.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Guadalupe Abigail Gonzalez Hernandez', '2023-05-24 19:18:07', NULL),
(702, 'anuar.gauna@docente.univer-gdl.edu.mx', 2, 1, 'Anuar Fernando Gauna Horta', '2023-05-24 19:18:07', NULL),
(703, 'karla.taylor@docente.univer-gdl.edu.mx', 2, 1, 'Karla Maria Taylor Ponce', '2023-05-24 19:18:07', NULL),
(704, 'erick.fierros@docente.univer-gdl.edu.mx', 2, 1, 'Erick Gibrann Fierros Rios', '2023-05-24 19:18:07', NULL),
(705, 'luis.reyes@docente.univer-gdl.edu.mx', 2, 1, 'Luis Angel Reyes Chavez', '2023-05-24 19:18:07', NULL),
(706, 'yaneth.gomez@docente.univer-gdl.edu.mx', 2, 1, 'Yaneth Gomez Chavarria', '2023-05-24 19:18:07', NULL),
(707, 'emma.cervantes@docente.univer-gdl.edu.mx', 2, 1, 'Emma Jacqueline Cervantes Gutierrez', '2023-05-24 19:18:08', NULL),
(708, 'rocio.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'Rocio Isabel Jimenez Ramirez', '2023-05-24 19:18:08', NULL),
(709, 'rodolfo.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Rodolfo Alberto Sanchez Ramos', '2023-05-24 19:18:08', NULL),
(710, 'ana.delaconcha@docente.univer-gdl.edu.mx', 2, 1, 'Ana Luisa De La Concha Perales', '2023-05-24 19:18:08', NULL),
(711, 'selene.guerrero@docente.univer-gdl.edu.mx', 2, 1, 'Selene Michele Guerrero SantibaÃ±ez', '2023-05-24 19:18:08', NULL),
(712, 'rolando.villalobos@docente.univer-gdl.edu.mx', 2, 1, 'Rolando Villalobos Miranda', '2023-05-24 19:18:08', NULL),
(713, 'gabriela.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'Gabriela Ruiz Ruvalcaba', '2023-05-24 19:18:08', NULL),
(714, 'sergio.santillan@docente.univer-gdl.edu.mx', 2, 1, 'Sergio Adrian Santillan Benavides', '2023-05-24 19:18:08', NULL),
(715, 'eloiza.robles@docente.univer-gdl.edu.mx', 2, 1, 'Eloiza Robles PeÃ±a', '2023-05-24 19:18:08', NULL),
(716, 'jorge.herrera@docente.univer-gdl.edu.mx', 2, 1, 'Jorge Eduardo Herrera Campos', '2023-05-24 19:18:08', NULL),
(717, 'adan.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Adan Garcia Berumen', '2023-05-24 19:18:08', NULL),
(718, 'hugo.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Hugo Manuel Garcia Robles', '2023-05-24 19:18:08', NULL),
(719, 'alejandro.diaz@docente.univer-gdl.edu.mx', 2, 1, 'Alejandro Diaz Avila', '2023-05-24 19:18:08', NULL),
(720, 'rosa.santana@docente.univer-gdl.edu.mx', 2, 1, 'Rosa Maria Santana Vazquez', '2023-05-24 19:18:08', NULL),
(721, 'victor.herrera@docente.univer-gdl.edu.mx', 2, 1, 'Victor Manuel Herrera Ochoa', '2023-05-24 19:18:08', NULL),
(722, 'andres.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Andres Lopez Mojarro', '2023-05-24 19:18:09', NULL),
(723, 'lilian.perez@docente.univer-gdl.edu.mx', 2, 1, 'Lilian Celeste Perez Lacomba', '2023-05-24 19:18:09', NULL),
(724, 'florencio.xolo@docente.univer-gdl.edu.mx', 2, 1, 'Florencio Xolo Velasco', '2023-05-24 19:18:09', NULL),
(725, 'edgar.cossyleon@docente.univer-gdl.edu.mx', 2, 1, 'Edgar Elias Cossy Leon Cabrera', '2023-05-24 19:18:09', NULL),
(726, 'jose.elizalde@docente.univer-gdl.edu.mx', 2, 1, 'Jose Francisco Elizalde Rodriguez', '2023-05-24 19:18:09', NULL),
(727, 'ruben.valadez@docente.univer-gdl.edu.mx', 2, 1, 'Ruben Valadez Escamilla', '2023-05-24 19:18:09', NULL),
(728, 'nereyda.morgan@docente.univer-gdl.edu.mx', 2, 1, 'Nereyda Morgan Torres', '2023-05-24 19:18:09', NULL),
(729, 'maria.nieto@docente.univer-gdl.edu.mx', 2, 1, 'Maria De Lourdes Nieto Luna', '2023-05-24 19:18:09', NULL),
(730, 'diego.diaz@docente.univer-gdl.edu.mx', 2, 1, 'Diego Diaz De La PeÃ±a', '2023-05-24 19:18:09', NULL),
(731, 'jose.bernal@docente.univer-gdl.edu.mx', 2, 1, 'Jose Bernal Ramirez', '2023-05-24 19:18:09', NULL),
(732, 'sebastian.guerrero@docente.univer-gdl.edu.mx', 2, 1, 'Sebastian Guerrero Vidal', '2023-05-24 19:18:09', NULL),
(733, 'karla.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Karla Sarahi Lopez Vargas', '2023-05-24 19:18:09', NULL),
(734, 'pablo.salinas@docente.univer-gdl.edu.mx', 2, 1, 'Pablo Jesus Salinas Osornio', '2023-05-24 19:18:09', NULL),
(735, 'abraham.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'Abraham Alberto Ramirez Mendoza', '2023-05-24 19:18:09', NULL),
(736, 'manuel.gaxiola@docente.univer-gdl.edu.mx', 2, 1, 'Manuel De Jesus Gaxiola Zamudio', '2023-05-24 19:18:09', NULL),
(737, 'hector.navarro@docente.univer-gdl.edu.mx', 2, 1, 'Hector Alejandro Navarro Parra', '2023-05-24 19:18:10', NULL),
(738, 'marco.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'Marco Dery Espinoza Santana', '2023-05-24 19:18:10', NULL),
(739, 'sandybel.nolasco@docente.univer-gdl.edu.mx', 2, 1, 'Sandybel Nolasco Delgado', '2023-05-24 19:18:10', NULL),
(740, 'heriberto.yanez@docente.univer-gdl.edu.mx', 2, 1, 'Heriberto YaÃ±ez Gloria', '2023-05-24 19:18:10', NULL),
(741, 'paola.amezquita@docente.univer-gdl.edu.mx', 2, 1, 'Paola Noehmi Amezquita Velasco', '2023-05-24 19:18:10', NULL),
(742, 'jose.ambriz@docente.univer-gdl.edu.mx', 2, 1, 'Jose Lopez Ambriz', '2023-05-24 19:18:10', NULL),
(743, 'juan.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'Juan Luis Ruiz Torres', '2023-05-24 19:18:10', NULL),
(744, 'fabiola.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Fabiola Abigail Gonzalez Hernandez', '2023-05-24 19:18:10', NULL),
(745, 'luis.montes@docente.univer-gdl.edu.mx', 2, 1, 'Luis Carlos Montes Rodriguez', '2023-05-24 19:18:10', NULL),
(746, 'juan.flores@docente.univer-gdl.edu.mx', 2, 1, 'Juan Carlos Flores Basulto', '2023-05-24 19:18:10', NULL),
(747, 'paula.carrillo@docente.univer-gdl.edu.mx', 2, 1, 'Paula Susana Carrillo Viera', '2023-05-24 19:18:10', NULL),
(748, 'bernando.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Bernando Sanchez Gutierrez', '2023-05-24 19:18:10', NULL),
(749, 'raul.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'Raul Arturo Ruiz Ponce', '2023-05-24 19:18:10', NULL),
(750, 'elisa.uribe@docente.univer-gdl.edu.mx', 2, 1, 'Elisa Yamina Uribe Flores', '2023-05-24 19:18:10', NULL),
(751, 'alberto.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Jose Alberto Gonzalez Flores', '2023-05-24 19:18:10', NULL),
(752, 'itzel.flores@docente.univer-gdl.edu.mx', 2, 1, 'Itzel Ariadna Flores OrdoÃ±ez', '2023-05-24 19:18:11', NULL),
(753, 'ernesto.miramontes@docente.univer-gdl.edu.mx', 2, 1, 'Ernesto Miramontes Meneses', '2023-05-24 19:18:11', NULL),
(754, 'cynthia.marquez@docente.univer-gdl.edu.mx', 2, 1, 'Cynthia Marquez Bevilacqua', '2023-05-24 19:18:11', NULL),
(755, 'monica.galan@docente.univer-gdl.edu.mx', 2, 1, 'Monica Guadalupe Galan Leyte', '2023-05-24 19:18:11', NULL),
(756, 'rosa.mendez@docente.univer-gdl.edu.mx', 2, 1, 'Rosa Margarita Mendez Garibay', '2023-05-24 19:18:11', NULL),
(757, 'laura.olvera@docente.univer-gdl.edu.mx', 2, 1, 'Laura Elizabeth Olvera Ledesma', '2023-05-24 19:18:11', NULL),
(758, 'xochitl.delarosa@docente.univer-gdl.edu.mx', 2, 1, 'Xochitl Susana De La Rosa Lopez', '2023-05-24 19:18:11', NULL),
(759, 'pablo.esteban@docente.univer-gdl.edu.mx', 2, 1, 'Pablo Sergio Esteban Montes', '2023-05-24 19:18:11', NULL),
(760, 'alfredo.anica@docente.univer-gdl.edu.mx', 2, 1, 'Alfredo Aldair Anica Loera', '2023-05-24 19:18:11', NULL),
(761, 'andrea.ilustre@docente.univer-gdl.edu.mx', 2, 1, 'Andrea Carolina Ilustre Vidaurre', '2023-05-24 19:18:11', NULL),
(762, 'octavio.covarrubias@docente.univer-gdl.edu.mx', 2, 1, 'Octavio Covarrubias Vargas', '2023-05-24 19:18:11', NULL),
(763, 'pilar.santana@docente.univer-gdl.edu.mx', 2, 1, 'Pilar Andrea Santana Partida', '2023-05-24 19:18:11', NULL),
(764, 'julia.soto@docente.univer-gdl.edu.mx', 2, 1, 'Julia Sarahi Soto Tovar', '2023-05-24 19:18:11', NULL),
(765, 'joshua.dominguez@docente.univer-gdl.edu.mx', 2, 1, 'Joshua Dominguez Ruelas', '2023-05-24 19:18:11', NULL),
(766, 'luis.correa@docente.univer-gdl.edu.mx', 2, 1, 'Luis Antonio Correa Gomez', '2023-05-24 19:18:11', NULL),
(767, 'giezi.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'Giezi Azareel Gutierrez Cano', '2023-05-24 19:18:11', NULL),
(768, 'natalia.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Natalia De La Rosa Martinez Cifuentes', '2023-05-24 19:18:12', NULL),
(769, 'alejandra.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Alejandra Sanchez Martinez', '2023-05-24 19:18:12', NULL),
(770, 'javier.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Javier Garcia Manriquez', '2023-05-24 19:18:12', NULL),
(771, 'juan.tellez@docente.univer-gdl.edu.mx', 2, 1, 'Juan Carlos Tellez Castillo', '2023-05-24 19:18:12', NULL),
(772, 'ana.burgara@docente.univer-gdl.edu.mx', 2, 1, 'Ana Paulina Burgara Gutierrez', '2023-05-24 19:18:12', NULL),
(773, 'jose.lomeli@docente.univer-gdl.edu.mx', 2, 1, 'Jose Antonio Lomeli BriseÃ±o', '2023-05-24 19:18:12', NULL),
(774, 'paulina.morales@docente.univer-gdl.edu.mx', 2, 1, 'Maria Paulina Morales Romo', '2023-05-24 19:18:12', NULL),
(775, 'oscar.chavez@docente.univer-gdl.edu.mx', 2, 1, 'Oscar Yoshigei Chavez Flores', '2023-05-24 19:18:12', NULL),
(776, 'antonio.gamez@docente.univer-gdl.edu.mx', 2, 1, 'Antonio Luis Gamez Gastelum', '2023-05-24 19:18:12', NULL),
(777, 'jorge.chamorro@docente.univer-gdl.edu.mx', 2, 1, 'Jorge Alberto Chamorro Martinez', '2023-05-24 19:18:12', NULL),
(778, 'jesus.fabian@docente.univer-gdl.edu.mx', 2, 1, 'Jesus Humberto Fabian Arciniega', '2023-05-24 19:18:12', NULL),
(779, 'dalia.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'Dalia Guadalupe Hernandez Martinez', '2023-05-24 19:18:13', NULL),
(780, 'erick.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Erick Adrian Rodriguez Ramirez', '2023-05-24 19:18:13', NULL),
(781, 'jose.carlos@docente.univer-gdl.edu.mx', 2, 1, 'Jose David Carlos Navarro', '2023-05-24 19:18:13', NULL),
(782, 'eduardo.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Eduardo Martinez Robles', '2023-05-24 19:18:13', NULL),
(783, 'citlalin.vega@docente.univer-gdl.edu.mx', 2, 1, 'Citlalin Vega Roman', '2023-05-24 19:18:13', NULL),
(784, 'maria.padilla@docente.univer-gdl.edu.mx', 2, 1, 'Maria Fernanda Padilla Flores', '2023-05-24 19:18:13', NULL),
(785, 'juan.salazar@docente.univer-gdl.edu.mx', 2, 1, 'Juan Pablo Salazar Satrustegui', '2023-05-24 19:18:13', NULL),
(786, 'susana.velazco@docente.univer-gdl.edu.mx', 2, 1, 'Susana Del Carmen Velazco Munguia', '2023-05-24 19:18:13', NULL),
(787, 'damian.castillo@docente.univer-gdl.edu.mx', 2, 1, 'Damian De Jesus Castillo Preciado', '2023-05-24 19:18:13', NULL),
(788, 'maria.jacobo@docente.univer-gdl.edu.mx', 2, 1, 'Maria De Jesus Jacobo Melendez', '2023-05-24 19:18:13', NULL),
(789, 'sandra.diaz@docente.univer-gdl.edu.mx', 2, 1, 'Sandra Mireya Diaz Ortega', '2023-05-24 19:18:13', NULL),
(790, 'erik.duran@docente.univer-gdl.edu.mx', 2, 1, 'Erik Gerardo Duran Solis', '2023-05-24 19:18:13', NULL),
(791, 'abigail.morales@docente.univer-gdl.edu.mx', 2, 1, 'Abigail Morales Carreon', '2023-05-24 19:18:13', NULL),
(792, 'octavio.aldrete@docente.univer-gdl.edu.mx', 2, 1, 'Octavio Augusto Aldrete Marquez', '2023-05-24 19:18:13', NULL),
(793, 'ruben.willman@docente.univer-gdl.edu.mx', 2, 1, 'Ruben Alejandro Willman De La Mora', '2023-05-24 19:18:13', NULL),
(794, 'alejandro.orozco@docente.univer-gdl.edu.mx', 2, 1, 'Alejandro Orozco Alonso', '2023-05-24 19:18:14', NULL),
(795, 'victor.mendez@docente.univer-gdl.edu.mx', 2, 1, 'Victor Donovan Mendez Luna', '2023-05-24 19:18:14', NULL),
(796, 'alberto.arcos@docente.univer-gdl.edu.mx', 2, 1, 'Alberto Arcos Sotomayor', '2023-05-24 19:18:14', NULL),
(797, 'edgar.lares@docente.univer-gdl.edu.mx', 2, 1, 'Edgar Manuel Lares Guerrero', '2023-05-24 19:18:14', NULL),
(798, 'juan.ortiz@docente.univer-gdl.edu.mx', 2, 1, 'Juan Carlos Ortiz Alvarez', '2023-05-24 19:18:14', NULL),
(799, 'jessica.villasenor@docente.univer-gdl.edu.mx', 2, 1, 'Jessica Iveth VillaseÃ±or Diaz', '2023-05-24 19:18:14', NULL),
(800, 'gerardo.cazarez@docente.univer-gdl.edu.mx', 2, 1, 'Gerardo Cazarez Navarro', '2023-05-24 19:18:14', NULL),
(801, 'ricardo.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Ricardo Martinez Magallanes', '2023-05-24 19:18:14', NULL),
(802, 'monica.ponce@docente.univer-gdl.edu.mx', 2, 1, 'Monica Leticia Ponce Vazquez', '2023-05-24 19:18:14', NULL),
(803, 'ernesto.heredia@docente.univer-gdl.edu.mx', 2, 1, 'Ernesto Heredia Santoyo', '2023-05-24 19:18:14', NULL),
(804, 'jesus.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'Jesus Jose Espinoza Suigo', '2023-05-24 19:18:14', NULL),
(805, 'israel.meza@docente.univer-gdl.edu.mx', 2, 1, 'Jose Israel Meza Romero', '2023-05-24 19:18:14', NULL),
(806, 'gabriel.aldana@docente.univer-gdl.edu.mx', 2, 1, 'Gabriel Alejandro Aldana Parra', '2023-05-24 19:18:14', NULL),
(807, 'miriam.barajas@docente.univer-gdl.edu.mx', 2, 1, 'Miriam Barajas Coronado', '2023-05-24 19:18:14', NULL),
(808, 'hector.brito@docente.univer-gdl.edu.mx', 2, 1, 'Hector Gustavo Brito Vera', '2023-05-24 19:18:15', NULL),
(809, 'cecilia.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Cecilia Lizbeth Garcia Cuevas', '2023-05-24 19:18:15', NULL),
(810, 'claudia.lara@docente.univer-gdl.edu.mx', 2, 1, 'Claudia Lara Escoto', '2023-05-24 19:18:15', NULL),
(811, 'diana.orozco@docente.univer-gdl.edu.mx', 2, 1, 'Diana Rebeca Orozco Lopez', '2023-05-24 19:18:15', NULL),
(812, 'alfredo.jacobo@docente.univer-gdl.edu.mx', 2, 1, 'Alfredo Abdel Jacobo Vazquez', '2023-05-24 19:18:15', NULL),
(813, 'maria.payan@docente.univer-gdl.edu.mx', 2, 1, 'Maria Guadalupe Payan Aparicio', '2023-05-24 19:18:15', NULL),
(814, 'betzaida.montero@docente.univer-gdl.edu.mx', 2, 1, 'Betzaida Montero Berumen', '2023-05-24 19:18:15', NULL),
(815, 'edna.vargas@docente.univer-gdl.edu.mx', 2, 1, 'Edna Maria Luisa Vargas Ramos', '2023-05-24 19:18:15', NULL),
(816, 'luis.montesdeoca@docente.univer-gdl.edu.mx', 2, 1, 'Luis Rafael Montes De Oca Valadez', '2023-05-24 19:18:15', NULL),
(817, 'carmen.peraza@docente.univer-gdl.edu.mx', 2, 1, 'Carmen Margarita Peraza Garcia', '2023-05-24 19:18:15', NULL),
(818, 'irma.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Irma Roxana Gonzalez PeÃ±a', '2023-05-24 19:18:15', NULL),
(819, 'miguel.santana@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Santana Rodriguez', '2023-05-24 19:18:15', NULL),
(820, 'nancy.tejada@docente.univer-gdl.edu.mx', 2, 1, 'Nancy Giebele Tejada Ruiz', '2023-05-24 19:18:15', NULL),
(821, 'elia.verdin@docente.univer-gdl.edu.mx', 2, 1, 'Elia Montsserrat Verdin Hernandez', '2023-05-24 19:18:15', NULL),
(822, 'gustavo.lozano@docente.univer-gdl.edu.mx', 2, 1, 'Gustavo Lozano Moreno', '2023-05-24 19:18:15', NULL),
(823, 'claudia.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'Claudia Rocio Gutierrez Moreno', '2023-05-24 19:18:15', NULL),
(824, 'erik.fernandez@docente.univer-gdl.edu.mx', 2, 1, 'Erik Paul Fernandez Bocardo', '2023-05-24 19:18:16', NULL),
(825, 'deborah.andere@docente.univer-gdl.edu.mx', 2, 1, 'Deborah Andere Albores', '2023-05-24 19:18:16', NULL),
(826, 'antonio.julian@docente.univer-gdl.edu.mx', 2, 1, 'Antonio Julian Iglesias', '2023-05-24 19:18:16', NULL),
(827, 'pedro.ramos@docente.univer-gdl.edu.mx', 2, 1, 'Pedro Ramos Vargas', '2023-05-24 19:18:16', NULL),
(828, 'yocelin.chavez@docente.univer-gdl.edu.mx', 2, 1, 'Yocelin Shalom Chavez Garcia', '2023-05-24 19:18:16', NULL),
(829, 'luis.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'Luis Hernandez Zavala', '2023-05-24 19:18:16', NULL),
(830, 'pamela.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Pamela Yazmin Garcia Ramos', '2023-05-24 19:18:16', NULL),
(831, 'damian.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Jose Damian Gonzalez Reyes', '2023-05-24 19:18:16', NULL),
(832, 'cesar.viglienzone@docente.univer-gdl.edu.mx', 2, 1, 'Cesar Artemio Viglienzone Villalobos', '2023-05-24 19:18:16', NULL),
(833, 'athziri.diaz@docente.univer-gdl.edu.mx', 2, 1, 'Athziri Adriana Diaz Martinez', '2023-05-24 19:18:16', NULL),
(834, 'mayra.cervantes@docente.univer-gdl.edu.mx', 2, 1, 'Mayra Nayely Cervantes Gutierrez', '2023-05-24 19:18:16', NULL),
(835, 'ramon.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Ramon Humberto Martinez Pardo', '2023-05-24 19:18:16', NULL),
(836, 'alfredo.delamora@docente.univer-gdl.edu.mx', 2, 1, 'Alfredo Ibarra De La Mora GonzÃ¡lez', '2023-05-24 19:18:16', NULL),
(837, 'josue.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'JosuÃ© Isaias Gonzalez Martinez', '2023-05-24 19:18:16', NULL),
(838, 'jorge.marquez@docente.univer-gdl.edu.mx', 2, 1, 'Jorge Marquez Villanueva', '2023-05-24 19:18:17', NULL),
(839, 'martin.avina@docente.univer-gdl.edu.mx', 2, 1, 'Martin AviÃ±a Avila', '2023-05-24 19:18:17', NULL),
(840, 'luis.duenas@docente.univer-gdl.edu.mx', 2, 1, 'Luis Manuel DueÃ±as VÃ¡zquez', '2023-05-24 19:18:17', NULL),
(841, 'angel.franco@docente.univer-gdl.edu.mx', 2, 1, 'Angel Eduardo Franco Alvarez', '2023-05-24 19:18:17', NULL),
(842, 'jessica.castellanos@docente.univer-gdl.edu.mx', 2, 1, 'Jessica Guadalupe Castellanos Castellanos', '2023-05-24 19:18:17', NULL),
(843, 'tania.ramirez@docente.univer-gdl.edu.mx', 2, 1, 'Tania Lizette Ramirez Casillas', '2023-05-24 19:18:17', NULL),
(844, 'fabricio.rivera@docente.univer-gdl.edu.mx', 2, 1, 'Fabricio Oliver Rivera Izazaga', '2023-05-24 19:18:17', NULL),
(845, 'jonathan.esquivel@docente.univer-gdl.edu.mx', 2, 1, 'Jonathan Israel Esquivel Diaz', '2023-05-24 19:18:17', NULL),
(846, 'jose.esparza@docente.univer-gdl.edu.mx', 2, 1, 'Jose Luis Esparza Ruiz', '2023-05-24 19:18:17', NULL),
(847, 'luis.thomas@docente.univer-gdl.edu.mx', 2, 1, 'Luis Gerardo Thomas Rico', '2023-05-24 19:18:17', NULL),
(848, 'jose.luna@docente.univer-gdl.edu.mx', 2, 1, 'Jose Dario Luna Ramos', '2023-05-24 19:18:17', NULL),
(849, 'brenda.estrada@docente.univer-gdl.edu.mx', 2, 1, 'Brenda Elizabeth Estrada Carillo', '2023-05-24 19:18:17', NULL),
(850, 'cesar.davalos@docente.univer-gdl.edu.mx', 2, 1, 'Cesar Alberto Davalos Santillan', '2023-05-24 19:18:17', NULL),
(851, 'rogelio.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Rogelio Sanchez May', '2023-05-24 19:18:17', NULL),
(852, 'daniel.lara@docente.univer-gdl.edu.mx', 2, 1, 'Daniel Lopez Lara', '2023-05-24 19:18:17', NULL),
(853, 'mario.diffo@docente.univer-gdl.edu.mx', 2, 1, 'Mario Alberto Diffo NuÃ±ez', '2023-05-24 19:18:17', NULL),
(854, 'hector.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Hector Gonzalez Marin', '2023-05-24 19:18:17', NULL),
(855, 'luis.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Luis Alberto Rodriguez Rosas', '2023-05-24 19:18:17', NULL),
(856, 'ofelia.aguilar@docente.univer-gdl.edu.mx', 2, 1, 'Ofelia Aguilar Nieves', '2023-05-24 19:18:17', NULL),
(857, 'gustavo.llauger@docente.univer-gdl.edu.mx', 2, 1, 'Gustavo Gerardo Llauger Llamas', '2023-05-24 19:18:18', NULL),
(858, 'esperanza.parada@docente.univer-gdl.edu.mx', 2, 1, 'Esperanza Aurora Parada Prado', '2023-05-24 19:18:18', NULL),
(859, 'claudia.bernal@docente.univer-gdl.edu.mx', 2, 1, 'Claudia Guadalupe Bernal Saavedra', '2023-05-24 19:18:18', NULL),
(860, 'daniel.alatorre@docente.univer-gdl.edu.mx', 2, 1, 'Daniel Alatorre Gordillo', '2023-05-24 19:18:18', NULL),
(861, 'humberto.desantiago@docente.univer-gdl.edu.mx', 2, 1, 'Humberto De Santiago Guerrero', '2023-05-24 19:18:18', NULL),
(862, 'rosa.muro@docente.univer-gdl.edu.mx', 2, 1, 'Rosa Isela Muro Hernandez', '2023-05-24 19:18:18', NULL),
(863, 'thania.aviles@docente.univer-gdl.edu.mx', 2, 1, 'Thania Walesa Aviles Sanchez', '2023-05-24 19:18:18', NULL),
(864, 'jose.naranjo@docente.univer-gdl.edu.mx', 2, 1, 'Jose De Jesus Garcia Naranjo', '2023-05-24 19:18:18', NULL),
(865, 'christian.vargas@docente.univer-gdl.edu.mx', 2, 1, 'Christian Moises Vargas Garcia', '2023-05-24 19:18:18', NULL),
(866, 'juan.esteban@docente.univer-gdl.edu.mx', 2, 1, 'Juan Carlos Esteban Quiroz', '2023-05-24 19:18:18', NULL),
(867, 'adrian.melchor@docente.univer-gdl.edu.mx', 2, 1, 'Adrian Melchor Cruz', '2023-05-24 19:18:18', NULL),
(868, 'bernardo.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Bernardo Sanchez Gutierrez', '2023-05-24 19:18:18', NULL),
(869, 'jose.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'JosÃ© De JesÃºs SÃ¡nchez Moreno', '2023-05-24 19:18:18', NULL),
(870, 'hector.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'HÃ©ctor Manuel Espinoza RamÃ­rez', '2023-05-24 19:18:18', NULL),
(871, 'tania.jauregui@docente.univer-gdl.edu.mx', 2, 1, 'Tania Sarai Jauregui Lopez', '2023-05-24 19:18:18', NULL),
(872, 'alejandro.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Alejandro Salvador Sanchez Torres', '2023-05-24 19:18:18', NULL),
(873, 'juan.medina@docente.univer-gdl.edu.mx', 2, 1, 'Juan Jose Medina MuÃ±oz', '2023-05-24 19:18:18', NULL),
(874, 'calixto.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Jose Calixto Gonzalez Maldonado', '2023-05-24 19:18:19', NULL),
(875, 'mariana.pineda@docente.univer-gdl.edu.mx', 2, 1, 'Mariana Pineda Islas', '2023-05-24 19:18:19', NULL),
(876, 'sahily.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'Sahily Ruiz Hernandez', '2023-05-24 19:18:19', NULL),
(877, 'ernesto.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Ernesto Javier Gonzalez Luna', '2023-05-24 19:18:19', NULL),
(878, 'jose.guerrero@docente.univer-gdl.edu.mx', 2, 1, 'Jose AndrÃ©s Guerrero Gonzalez', '2023-05-24 19:18:19', NULL),
(879, 'cindy.soto@docente.univer-gdl.edu.mx', 2, 1, 'Cindy Noemi Soto Jimenez', '2023-05-24 19:18:19', NULL),
(880, 'pablo.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Pablo Sanchez Martinez', '2023-05-24 19:18:19', NULL),
(881, 'alan.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'Alan Michel Gutierrez Torres', '2023-05-24 19:18:19', NULL),
(882, 'miguel.ordaz@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Felipe Ordaz Higadera', '2023-05-24 19:18:19', NULL),
(883, 'lenia.cuevas@docente.univer-gdl.edu.mx', 2, 1, 'Lenia Sofia Cuevas MontaÃ±o', '2023-05-24 19:18:19', NULL),
(884, 'pedro.arcos@docente.univer-gdl.edu.mx', 2, 1, 'Pedro Enrique Arcos Arellano', '2023-05-24 19:18:19', NULL),
(885, 'ana.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Ana Gabriel Martinez Chavez', '2023-05-24 19:18:19', NULL);
INSERT INTO `correos` (`id`, `correo`, `tipo`, `status`, `nombre`, `created_at`, `updated_at`) VALUES
(886, 'miguel.salinas@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Salinas Becerra', '2023-05-24 19:18:20', NULL),
(887, 'rodrigo.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Rodrigo Ignacio Lopez Guzman', '2023-05-24 19:18:20', NULL),
(888, 'emmanuel.rivera@docente.univer-gdl.edu.mx', 2, 1, 'Emmanuel Agustin Rivera Sanchez', '2023-05-24 19:18:20', NULL),
(889, 'claudia.clavillo@docente.univer-gdl.edu.mx', 2, 1, 'Claudia Maricela Clavillo Fernandez', '2023-05-24 19:18:20', NULL),
(890, 'marcia.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Marcia Gabriela Garcia Bracamontes', '2023-05-24 19:18:20', NULL),
(891, 'anahi.cosme@docente.univer-gdl.edu.mx', 2, 1, 'Anahi Lizbeth Cosme Rojas', '2023-05-24 19:18:20', NULL),
(892, 'wendy.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'Wendy Adriana Hernandez Arellano', '2023-05-24 19:18:20', NULL),
(893, 'tannia.delallave@docente.univer-gdl.edu.mx', 2, 1, 'Tannia De La Llave Guzman', '2023-05-24 19:18:20', NULL),
(894, 'luis.contreras@docente.univer-gdl.edu.mx', 2, 1, 'Luis Contreras Cardenas', '2023-05-24 19:18:20', NULL),
(895, 'montserrat.morelos@docente.univer-gdl.edu.mx', 2, 1, 'Montserrat Alejandra Morelos Aceves', '2023-05-24 19:18:20', NULL),
(896, 'mitsuo.yamamoto@docente.univer-gdl.edu.mx', 2, 1, 'Mitsuo Yamamoto Anaya', '2023-05-24 19:18:21', NULL),
(897, 'fernando.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Fernando Rodriguez Chavez', '2023-05-24 19:18:21', NULL),
(898, 'miguel.meza@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Meza Trinidad', '2023-05-24 19:18:21', NULL),
(899, 'eduardo.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Eduardo Daniel Sanchez Garcia', '2023-05-24 19:18:21', NULL),
(900, 'karla.pelayo@docente.univer-gdl.edu.mx', 2, 1, 'Karla Lizbeth Pelayo Aguila', '2023-05-24 19:18:21', NULL),
(901, 'rafael.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'Rafael Gutierrez Martinez', '2023-05-24 19:18:21', NULL),
(902, 'cecilia.baldovinos@docente.univer-gdl.edu.mx', 2, 1, 'Cecilia Baldovinos Casillas', '2023-05-24 19:18:21', NULL),
(903, 'abraham.chavez@docente.univer-gdl.edu.mx', 2, 1, 'Abraham Chavez Sandoval', '2023-05-24 19:18:21', NULL),
(904, 'javier.ortega@docente.univer-gdl.edu.mx', 2, 1, 'Javier Ortega Martinez', '2023-05-24 19:18:21', NULL),
(905, 'teresa.ipina@docente.univer-gdl.edu.mx', 2, 1, 'Teresa De Jesus IpiÃ±a IpiÃ±a', '2023-05-24 19:18:21', NULL),
(906, 'ignacio.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Ignacio Alfonso Martinez Jimenez', '2023-05-24 19:18:21', NULL),
(907, 'miguel.quintero@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Angel Quintero Arellano', '2023-05-24 19:18:21', NULL),
(908, 'francisco.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Manuel Rodriguez Garcia', '2023-05-24 19:18:21', NULL),
(909, 'maria.ruvalcaba@docente.univer-gdl.edu.mx', 2, 1, 'Maria Guadalupe Ruvalcaba Acosta', '2023-05-24 19:18:21', NULL),
(910, 'daniel.guerrero@docente.univer-gdl.edu.mx', 2, 1, 'Jose Daniel Guerrero Silva', '2023-05-24 19:18:21', NULL),
(911, 'ana.silva@docente.univer-gdl.edu.mx', 2, 1, 'Ana Cecilia Silva Morales', '2023-05-24 19:18:22', NULL),
(912, 'irma.perezgarza@docente.univer-gdl.edu.mx', 2, 1, 'Irma Catalina Perezgarza Paredes', '2023-05-24 19:18:22', NULL),
(913, 'luis.perez@docente.univer-gdl.edu.mx', 2, 1, 'Luis Fernando Lopez Perez', '2023-05-24 19:18:22', NULL),
(914, 'delourdes.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Maria De Lourdes Gonzalez Rodriguez', '2023-05-24 19:18:22', NULL),
(915, 'sergio.reynaga@docente.univer-gdl.edu.mx', 2, 1, 'Sergio Reynaga Martinez', '2023-05-24 19:18:22', NULL),
(916, 'jaqueline.horta@docente.univer-gdl.edu.mx', 2, 1, 'Jaqueline Horta Sanchez', '2023-05-24 19:18:22', NULL),
(917, 'edgar.cecanas@docente.univer-gdl.edu.mx', 2, 1, 'Edgar Alonso CeceÃ±as Gonzalez', '2023-05-24 19:18:22', NULL),
(918, 'jose.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Jose Alejandro Rodriguez Mejia', '2023-05-24 19:18:22', NULL),
(919, 'tanya.reyes@docente.univer-gdl.edu.mx', 2, 1, 'Tanya Karina Reyes Mota', '2023-05-24 19:18:22', NULL),
(920, 'jose.perez@docente.univer-gdl.edu.mx', 2, 1, 'Jose Armando Perez Gomez', '2023-05-24 19:18:22', NULL),
(921, 'ana.dominguez@docente.univer-gdl.edu.mx', 2, 1, 'Ana Dominguez Ortega', '2023-05-24 19:18:22', NULL),
(922, 'jessica.nungaray@docente.univer-gdl.edu.mx', 2, 1, 'Jessica Paulina Nungaray De Leon', '2023-05-24 19:18:23', NULL),
(923, 'santiago.castellanos@docente.univer-gdl.edu.mx', 2, 1, 'Santiago Heriberto Castellanos Cervantes', '2023-05-24 19:18:23', NULL),
(924, 'hilda.rivera@docente.univer-gdl.edu.mx', 2, 1, 'Hilda Rivera Ortiz', '2023-05-24 19:18:23', NULL),
(925, 'miguel.torres@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Torres Vazquez', '2023-05-24 19:18:23', NULL),
(926, 'miguel.mendoza@docente.univer-gdl.edu.mx', 2, 1, 'Miguel Angel Mendoza Mancilla', '2023-05-24 19:18:23', NULL),
(927, 'veronica.merigo@docente.univer-gdl.edu.mx', 2, 1, 'Veronica Merigo Salado', '2023-05-24 19:18:23', NULL),
(928, 'brayan.villalobos@docente.univer-gdl.edu.mx', 2, 1, 'Brayan Alberto Villalobos Lopez', '2023-05-24 19:18:23', NULL),
(929, 'gualberto.gomez@docente.univer-gdl.edu.mx', 2, 1, 'Gualberto Gomez Aguayo', '2023-05-24 19:18:23', NULL),
(930, 'nancy.reyes@docente.univer-gdl.edu.mx', 2, 1, 'Nancy Mileth Reyes Contreras', '2023-05-24 19:18:23', NULL),
(931, 'edgar.nunez@docente.univer-gdl.edu.mx', 2, 1, 'Edgar Eduardo NuÃ±ez Molina', '2023-05-24 19:18:23', NULL),
(932, 'francisco.gallegos@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Gallegos Gomez', '2023-05-24 19:18:23', NULL),
(933, 'leslie.cruz@docente.univer-gdl.edu.mx', 2, 1, 'Leslie Araceli Cruz Vazquez', '2023-05-24 19:18:23', NULL),
(934, 'luis.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Luis Raymundo Garcia Calderon', '2023-05-24 19:18:23', NULL),
(935, 'cristina.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Cristina Lopez Arizaga', '2023-05-24 19:18:23', NULL),
(936, 'moises.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Moises Eduardo RodrÃ­guez Flores', '2023-05-24 19:18:23', NULL),
(937, 'mariana.mora@docente.univer-gdl.edu.mx', 2, 1, 'Mariana Guadalupe Mora Marquez', '2023-05-24 19:18:24', NULL),
(938, 'omar.flores@docente.univer-gdl.edu.mx', 2, 1, 'Omar Flores Espinoza', '2023-05-24 19:18:24', NULL),
(939, 'pablo.garay@docente.univer-gdl.edu.mx', 2, 1, 'Pablo Garay Lopez', '2023-05-24 19:18:24', NULL),
(940, 'gabriel.flores@docente.univer-gdl.edu.mx', 2, 1, 'Gabriel Eduardo Flores VÃ¡zquez', '2023-05-24 19:18:24', NULL),
(941, 'oscar.vazquez@docente.univer-gdl.edu.mx', 2, 1, 'Oscar Ricardo Vazquez Murillo', '2023-05-24 19:18:24', NULL),
(942, 'francisco.negrete@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Javier Negrete Carrillo', '2023-05-24 19:18:24', NULL),
(943, 'francisco.coronado@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Ivanovich Coronado Moran', '2023-05-24 19:18:24', NULL),
(944, 'daniel.camacho@docente.univer-gdl.edu.mx', 2, 1, 'Daniel Jesus Camacho Paz', '2023-05-24 19:18:24', NULL),
(945, 'griselda.madrigal@docente.univer-gdl.edu.mx', 2, 1, 'Griselda Madrigal Rodriguez', '2023-05-24 19:18:24', NULL),
(946, 'ernesto.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Francisco Ernesto GarcÃ­a Garcia', '2023-05-24 19:18:24', NULL),
(947, 'maria.carrillo@docente.univer-gdl.edu.mx', 2, 1, 'Maria De Los Ãngeles Carrillo Cuevas', '2023-05-24 19:18:24', NULL),
(948, 'elizabeth.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'Elizabeth Gonzalez Villeth', '2023-05-24 19:18:24', NULL),
(949, 'omar.lopez@docente.univer-gdl.edu.mx', 2, 1, 'Omar Said Lopez Gaxiola', '2023-05-24 19:18:24', NULL),
(950, 'alejandra.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Alejandra Martinez Silva', '2023-05-24 19:18:25', NULL),
(951, 'jose.vargas@docente.univer-gdl.edu.mx', 2, 1, 'Jose Antonio Vargas Amezcua', '2023-05-24 19:18:25', NULL),
(952, 'jorge.gomez@docente.univer-gdl.edu.mx', 2, 1, 'Jorge Alberto Gomez Lopez', '2023-05-24 19:18:25', NULL),
(953, 'salvador.bermudez@docente.univer-gdl.edu.mx', 2, 1, 'Salvador Bermudez Mesa', '2023-05-24 19:18:25', NULL),
(954, 'fabian.diaz@docente.univer-gdl.edu.mx', 2, 1, 'Fabian Diaz Villa', '2023-05-24 19:18:25', NULL),
(955, 'jose.enciso@docente.univer-gdl.edu.mx', 2, 1, 'Enciso GarcÃ­a JosÃ© Manuel', '2023-05-24 19:18:25', NULL),
(956, 'hugo.esparza@docente.univer-gdl.edu.mx', 2, 1, 'Esparza Tavares Hugo OdÃ­n', '2023-05-24 19:18:25', NULL),
(957, 'salvador.cruz@docente.univer-gdl.edu.mx', 2, 1, 'Salvador Daniel Cruz Salazar', '2023-05-24 19:18:25', NULL),
(958, 'saira.haro@docente.univer-gdl.edu.mx', 2, 1, 'Saira Yanetzy Haro Apodaca', '2023-05-24 19:18:25', NULL),
(959, 'edith.espinoza@docente.univer-gdl.edu.mx', 2, 1, 'Edith Aracely Espinoza Cruz', '2023-05-24 19:18:25', NULL),
(960, 'luz.medina@docente.univer-gdl.edu.mx', 2, 1, 'Luz Adriana Medina Rodriguez', '2023-05-24 19:18:25', NULL),
(961, 'karla.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Karla Ivonne Garcia Zamudio', '2023-05-24 19:18:25', NULL),
(962, 'moises.ortiz@docente.univer-gdl.edu.mx', 2, 1, 'Moises Rafael Ortiz DÃ­as', '2023-05-24 19:18:26', NULL),
(963, 'alfredo.gonzalez@docente.univer-gdl.edu.mx', 2, 1, 'JosÃ© Alfredo Gonzalez Panduro', '2023-05-24 19:18:26', NULL),
(964, 'luis.mariscal@docente.univer-gdl.edu.mx', 2, 1, 'JosÃ© Luis GarcÃ­a Mariscal', '2023-05-24 19:18:26', NULL),
(965, 'lizbeth.ruiz@docente.univer-gdl.edu.mx', 2, 1, 'Lizbeth Guadalupe Ruiz Silva', '2023-05-24 19:18:26', NULL),
(966, 'luis.zavala@docente.univer-gdl.edu.mx', 2, 1, 'Luis Daniel Zavala Aguilar', '2023-05-24 19:18:26', NULL),
(967, 'goretty.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Goretty Araceli Sanchez Jauregui', '2023-05-24 19:18:26', NULL),
(968, 'armando.gomez@docente.univer-gdl.edu.mx', 2, 1, 'Jorge Armando Gomez Espinoza', '2023-05-24 19:18:26', NULL),
(969, 'imelda.razo@docente.univer-gdl.edu.mx', 2, 1, 'Imelda Razo Paredes', '2023-05-24 19:18:26', NULL),
(970, 'mario.ibarra@docente.univer-gdl.edu.mx', 2, 1, 'Mario RamÃ³n Ibarra Castro', '2023-05-24 19:18:26', NULL),
(971, 'cinthia.munoz@docente.univer-gdl.edu.mx', 2, 1, 'Cinthia Guadalupe MuÃ±oz Aguilar', '2023-05-24 19:18:26', NULL),
(972, 'david.robles@docente.univer-gdl.edu.mx', 2, 1, 'David Eduardo Robles Ortega', '2023-05-24 19:18:26', NULL),
(973, 'tonatih.jimenez@docente.univer-gdl.edu.mx', 2, 1, 'Jimenez Garcia Tonatih', '2023-05-24 19:18:26', NULL),
(974, 'eder.carcano@docente.univer-gdl.edu.mx', 2, 1, 'Eder CarcaÃ±o Fonseca', '2023-05-24 19:18:26', NULL),
(975, 'ricardo.laguna@docente.univer-gdl.edu.mx', 2, 1, 'Ricardo Laguna Velasco', '2023-05-24 19:18:27', NULL),
(976, 'cindy.delangel@docente.univer-gdl.edu.mx', 2, 1, 'Cindy Vanessa Del Angel Roman', '2023-05-24 19:18:27', NULL),
(977, 'cesar.pantoja@docente.univer-gdl.edu.mx', 2, 1, 'Cesar Omar Pantoja Torres', '2023-05-24 19:18:27', NULL),
(978, 'ana.laura@docente.univer-gdl.edu.mx', 2, 1, 'Ana Laura ChÃ¡vez Velarde', '2023-05-24 19:18:27', NULL),
(979, 'gerardo.moreno@docente.univer-gdl.edu.mx', 2, 1, 'Gerardo Moreno Paredes', '2023-05-24 19:18:27', NULL),
(980, 'ivonne.chavez@docente.univer-gdl.edu.mx', 2, 1, 'Ivonne Chavez Centeno', '2023-05-24 19:18:27', NULL),
(981, 'joaquin.nunez@docente.univer-gdl.edu.mx', 2, 1, 'Joaquin Alberto NuÃ±ez Garcia', '2023-05-24 19:18:27', NULL),
(982, 'alberto.martinez@docente.univer-gdl.edu.mx', 2, 1, 'Alberto Martinez Torres', '2023-05-24 19:18:27', NULL),
(983, 'jairo.willman@docente.univer-gdl.edu.mx', 2, 1, 'Jairo De Jesus Willman De La Mora', '2023-05-24 19:18:27', NULL),
(984, 'juan.quino@docente.univer-gdl.edu.mx', 2, 1, 'Juan Abraham Quino Mendoza', '2023-05-24 19:18:27', NULL),
(985, 'laura.angulo@docente.univer-gdl.edu.mx', 2, 1, 'Laura Carolina Angulo Ruiz', '2023-05-24 19:18:27', NULL),
(986, 'claudia.zavala@docente.univer-gdl.edu.mx', 2, 1, 'Claudia Yarely Zavala Aguirre', '2023-05-24 19:18:27', NULL),
(987, 'ireland.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Ireland Delma Nerea Sanchez Barron', '2023-05-24 19:18:27', NULL),
(988, 'rodrigo.chavez@docente.univer-gdl.edu.mx', 2, 1, 'Rodrigo Chavez Andrade', '2023-05-24 19:18:27', NULL),
(989, 'salvador.salcedo@docente.univer-gdl.edu.mx', 2, 1, 'Salvador Salcedo Hernandez', '2023-05-24 19:18:27', NULL),
(990, 'abigail.calleja@docente.univer-gdl.edu.mx', 2, 1, 'Abigail Calleja Witt', '2023-05-24 19:18:27', NULL),
(991, 'andrea.lujano@docente.univer-gdl.edu.mx', 2, 1, 'Andrea Veronica Lujano Benitez', '2023-05-24 19:18:28', NULL),
(992, 'diana.bravo@docente.univer-gdl.edu.mx', 2, 1, 'Diana Bravo Rico', '2023-05-24 19:18:28', NULL),
(993, 'iris.meza@docente.univer-gdl.edu.mx', 2, 1, 'Iris Lisett Meza Ortega', '2023-05-24 19:18:28', NULL),
(994, 'susana.sanchez@docente.univer-gdl.edu.mx', 2, 1, 'Susana Alejandra Sanchez Amezquita', '2023-05-24 19:18:28', NULL),
(995, 'adela.haro@docente.univer-gdl.edu.mx', 2, 1, 'Adela Haro Guillen', '2023-05-24 19:18:28', NULL),
(996, 'pablo.montes@docente.univer-gdl.edu.mx', 2, 1, 'Juan Pablo Montes Torres', '2023-05-24 19:18:28', NULL),
(997, 'maria.maya@docente.univer-gdl.edu.mx', 2, 1, 'Maya Rodriguez Maria Elena', '2023-05-24 19:18:28', NULL),
(998, 'teresa.vera@docente.univer-gdl.edu.mx', 2, 1, 'Vera Chavez Teresa De Jesus', '2023-05-24 19:18:28', NULL),
(999, 'cuauhtemoc.molina@docente.univer-gdl.edu.mx', 2, 1, 'Cuauhtemoc Molina Rubalcava', '2023-05-24 19:18:28', NULL),
(1000, 'bryan.ramos@docente.univer-gdl.edu.mx', 2, 1, 'Ramos VillafaÃ±a Bryan Alejandro', '2023-05-24 19:18:28', NULL),
(1001, 'jorge.solorzano@docente.univer-gdl.edu.mx', 2, 1, 'Jorge Solorzano Guzman', '2023-05-24 19:18:28', NULL),
(1002, 'pedro.ortiz@docente.univer-gdl.edu.mx', 2, 1, 'Ortiz Oliveros Pedro', '2023-05-24 19:18:28', NULL),
(1003, 'samantha.navarro@docente.univer-gdl.edu.mx', 2, 1, 'Navarro Enriquez Samantha Viridiana', '2023-05-24 19:18:28', NULL),
(1004, 'sergio.bernal@docente.univer-gdl.edu.mx', 2, 1, 'Sergio Eduardo Bernal Higareda', '2023-05-24 19:18:28', NULL),
(1005, 'carlos.barraza@docente.univer-gdl.edu.mx', 2, 1, 'Carlos Manuel Barraza Rodriguez', '2023-05-24 19:18:28', NULL),
(1006, 'nayeli.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Nayeli Garcia Ramos', '2023-05-24 19:18:28', NULL),
(1007, 'monica.nunez@docente.univer-gdl.edu.mx', 2, 1, 'Monica Magdalena NuÃ±ez Andalon', '2023-05-24 19:18:28', NULL),
(1008, 'ana.trujillo@docente.univer-gdl.edu.mx', 2, 1, 'Ana Cristina Trujillo Godinez', '2023-05-24 19:18:28', NULL),
(1009, 'octavio.castaneda@docente.univer-gdl.edu.mx', 2, 1, 'Octavio CastaÃ±eda Garcia', '2023-05-24 19:18:28', NULL),
(1010, 'elda.macias@docente.univer-gdl.edu.mx', 2, 1, 'Elda Gabriela Macias Flores', '2023-05-24 19:18:29', NULL),
(1011, 'josue.gutierrez@docente.univer-gdl.edu.mx', 2, 1, 'GutiÃ©rrez Olayo Josue Daniel', '2023-05-24 19:18:29', NULL),
(1012, 'fatima.hernandez@docente.univer-gdl.edu.mx', 2, 1, 'Fatima Hernandez Gomez', '2023-05-24 19:18:29', NULL),
(1013, 'hector.castaneda@docente.univer-gdl.edu.mx', 2, 1, 'Hector Manuel CastaÃ±eda Hernandez', '2023-05-24 19:18:29', NULL),
(1014, 'cain.diaz@docente.univer-gdl.edu.mx', 2, 1, 'DÃ­az Fonseca CaÃ­n Abel', '2023-05-24 19:18:29', NULL),
(1015, 'pablo.morales@docente.univer-gdl.edu.mx', 2, 1, 'Morales DÃ­az Pablo David', '2023-05-24 19:18:29', NULL),
(1016, 'maria.godinez@docente.univer-gdl.edu.mx', 2, 1, 'Godinez Salas Maria Del Carmen', '2023-05-24 19:18:29', NULL),
(1017, 'manuel.mercado@docente.univer-gdl.edu.mx', 2, 1, 'Manuel Mercado Ruelas', '2023-05-24 19:18:29', NULL),
(1018, 'eva.bracamontes@docente.univer-gdl.edu.mx', 2, 1, 'Bracamontes GarcÃ­a Eva Viridiana', '2023-05-24 19:18:29', NULL),
(1019, 'emmanuel.ramos@docente.univer-gdl.edu.mx', 2, 1, 'Emmanuel Ramos RodrÃ­guez', '2023-05-24 19:18:29', NULL),
(1020, 'luis.rojas@docente.univer-gdl.edu.mx', 2, 1, 'Rojas Sosa Luis Ernesto', '2023-05-24 19:18:29', NULL),
(1021, 'alicia.martinez@docente.univer-gdl.edu.mx', 2, 1, 'MartÃ­nez Medrano Alicia Amparo LucÃ­a', '2023-05-24 19:18:29', NULL),
(1022, 'victor.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Garcia Gonzalez Victor Gabriel', '2023-05-24 19:18:29', NULL),
(1023, 'ignacio.aguirre@docente.univer-gdl.edu.mx', 2, 1, 'Ignacio Aguirre Tenorio', '2023-05-24 19:18:29', NULL),
(1024, 'ivonne.morales@docente.univer-gdl.edu.mx', 2, 1, 'Morales Flores Ivonne Adriana', '2023-05-24 19:18:30', NULL),
(1025, 'rebeca.navarro@docente.univer-gdl.edu.mx', 2, 1, 'Rebeca Alejandra Navarro Grajeda', '2023-05-24 19:18:30', NULL),
(1026, 'alvaro.rodriguez@docente.univer-gdl.edu.mx', 2, 1, 'Ãlvaro Miguel RodrÃ­guez JÃ¡uregui', '2023-05-24 19:18:30', NULL),
(1027, 'josue.garcia@docente.univer-gdl.edu.mx', 2, 1, 'Josue Brian Garcia Olva', '2023-05-24 19:18:30', NULL),
(1028, 'cyntia.cedano@docente.univer-gdl.edu.mx', 2, 1, 'Cedano Castillo Cyntia Alejandra', '2023-05-24 19:18:30', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_05_24_162813_create_sessions_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provicional_correos`
--

CREATE TABLE `provicional_correos` (
  `correo` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `provicional_correos`
--

INSERT INTO `provicional_correos` (`correo`, `created_at`, `updated_at`) VALUES
('abel.garcia@docente.univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('abigail.calleja@docente.univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('abigail.morales@docente.univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('alan.martinez@univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('alberto.arcos@docente.univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('alejandra.sanchez@docente.univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('alejandrina.lopez@univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24'),
('alejandro.raga@univer-gdl.edu.mx', '2023-05-31 22:42:24', '2023-05-31 22:42:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('FguSwmU0aBeW4iL07YOf29CQ0asU9ntoqE8synYt', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUXNhTktkVENSODRLMUwxdGFGRFExdTJqbUttUHZhdklQYTZRNjBiYyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9lbnZpYXIiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEwJEFJMjF4REllcmZySG9GTXo2cGJlQU8zYlRpUlFBdVJoaHo0VHhSUmh0QUdTT0oueTB5RUxxIjt9', 1685476178),
('x6HKkdRMqXfuM0reR3S3GIML4D4S8muXSHBPFfez', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZm9UY1Q1TmY3NXR2N2paUjJ5dDY1WE83RUh6M0l2RXRJRkd2Rkx0UCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9saXN0YV9jb3JyZW9zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRBSTIxeERJZXJmckhvRk16NnBiZUFPM2JUaVJRQXVSaGh6NFR4UlJodEFHU09KLnkweUVMcSI7fQ==', 1685553510);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `status`
--

INSERT INTO `status` (`id`, `descripcion`, `created_at`, `updated_at`) VALUES
(1, 'Activo', '2023-05-24 17:16:52', NULL),
(2, 'De Baja', '2023-05-24 17:16:52', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id`, `descripcion`, `created_at`, `updated_at`) VALUES
(1, 'Administrativo', '2023-05-24 18:35:59', NULL),
(2, 'Docente', '2023-05-24 17:12:16', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@univer.com', NULL, '$2y$10$AI21xDIerfrHoFMz6pbeAO3bTiRQAuRhhz4TxRRhtAGSOJ.y0yELq', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `correos`
--
ALTER TABLE `correos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indices de la tabla `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `correos`
--
ALTER TABLE `correos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1029;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
